<#
    .SYNOPSIS
        Business Continuity in a Box (BCiaB) is a tool to assist organisations to rapidly provision a secure Microsoft 365 tenant
        including Exchange Online and assocaited security controls in response to a business continuity event affecting an organisations information technology services.

    .DESCRIPTION
        The main features included in this version of the tool are:

        - Configuring an Emergency Access account in the tenant
        - Creating a catch-all mailbox in Exchange Online

        .NOTES
            Author		: Australian Cyber Security Centre
            File Name	: Invoke-BCiaB.ps1
            Version     : 0.9
        .LINK
            https://github.com/AustralianCyberSecurityCentre/BCiaB <- To be confirmed
            blueprint@asd.gov.au
    .EXAMPLE
        Invoke-BCiaB

    .PARAMETER WhatIf
        Provides a summary of the actions that will be taken which includes the changes that will be made to the tenant, but does not perform the actual actions.

    .PARAMETER Confirm
        Will prompt for confirmation before performing actions that will alter the tenant
#>
function Invoke-BCiaB {
    [CmdletBinding()]
    param(
        [object] $MyParams
    )

    #Process the manifest file to convert defined parameters into dynamic parameters.
    dynamicparam {
        $paramDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary

        #return the collection of dynmic parameters
        $paramDictionary
    }
    begin {
        try {
            if (-not $MyParams.ContainsKey('Confirm')) {
                $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
            }

            if (-not $MyParams.ContainsKey('WhatIf')) {
                $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
            }

            #Start Timer
            $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

            $configPath = Join-Path -Path $Script:ScriptPath -ChildPath "config"
        } catch {
            Write-Error $_
        }
    }
    process {
        try {
            #region BCIAB Profile
            <#
                Setup the profile object to use throughout the script.
                The profile contains information from the specified configuration file:
                * Output folder for files produced by the script, including logs
                * Logging configurations
                * Microsoft 365 components to configure

                The profile object also manages the state of connected sessions.
            #>
            $bciabProfileParams = @{
                Path     = $configPath
                FileName = "bciab.settings.config"
                MyParams = $MyParams
            }
            $BciabProfile = Initialize-BciabProfile @bciabProfileParams

            if ($null -eq $BciabProfile) {
                throw $Script:LocalData.Exception_BciabProfileNotCreated
            }
            #endregion BCIAB Profile

            #Start Transcript logging
            $transcript = Start-Transcript -Path $Script:BciabLogger.TranscriptLog

            #region M365 URIs
            #Get the common Microsoft 365 and Azure URI's and GUIDs for use throughout the script
            $m365ObjectParams = @{
                Path     = $configPath
                FileName = "m365.settings.config"
            }
            $M365Object = Initialize-M365Object @m365ObjectParams

            if ($null -eq $M365Object) {
                throw $Script:LocalData.Exception_M365SettingsNotAvailable
            }

            New-Variable -Name M365Settings -Value $M365Object -Scope Script -Force
            #endregion M365 URIs

            #region Dependencies Installation
            <#
                Install the required modules (could be done using Scripts to Process in the manifest,
                but needed more control over user scope and installation as had to remove dependencies at the end to clean up)
            #>
            $dependenciesFile = Join-Path -Path $configPath -ChildPath "bciab.dependencies.config"

            if (-not (Test-Path -Path $dependenciesFile)) {
                $logMsg = @{
                    MessageData = ($Script:LocalData.Error_DependenciesFileNotFound -f $dependenciesFile)
                    CallStack   = (Get-PSCallStack | Select-Object -First 1)
                    LogLevel    = "Error"
                    Tags        = @($Script:LocalData.Tag_Error)
                }

                Write-LogEntry @logMsg

                throw [System.IO.FileNotFoundException]::new(($Script:LocalData.Error_DependenciesFileNotFound -f $dependenciesFile))
            }

            $dependenciesConfig = (Get-Content $dependenciesFile -Raw) | ConvertFrom-Json

            $modulesNotInstalled = 0

            foreach ($dependency in $dependenciesConfig.Dependencies) {
                $modulesNotInstalled += Add-BciabDependency `
                    -ModuleName $dependency.ModuleName `
                    -RequiredVersion $dependency.RequiredVersion
            }

            if ($modulesNotInstalled -ge 1) {
                throw $Script:LocalData.Exception_DependencyInstall
            }

            $modulesNotImported = 0

            Write-Host "`r`n" -NoNewline
            Write-Host $Script:LocalData.Verbose_ImportingDependency `
                -NoNewline

            if ($modulesNotImported -ge 1) {
                Write-Host $Script:EmojiError
                throw $Script:LocalData.Exception_DependencyImport
            } else {
                Write-Host $Script:EmojiSuccess
            }
            #endregion Dependencies Installation

            #region Debug User
            #It's possible to have a debug user during development/testing to reduce the tediousness of continually entering a username and password.
            #DebugUser is only populated when the 'Debug' switch is passed during the BciabProfile creation
            if ($null -ne $BciabProfile.DebugUser) {
                $Credentials = $BciabProfile.DebugUser
            } else {
                $Credentials = Get-Credential
            }
            #endregion Debug User

            #Create the inital connection to the tenant using a Global Administration account
            Write-Host "`r`n" -NoNewline
            Write-Host ($Script:LocalData.Verbose_ConnectionCredential -f $Credentials.UserName) `
                -NoNewline

            $connectionParams = @{
                ConnectionType     = [ConnectionType]::Azure
                AuthenticationType = [AuthenticationType]::UserWithCredentials
                EnvironmentName    = [AzureEnvironment]::AzureCloud
                Credentials        = $Credentials
                RequiredRoles      = $BciabProfile.UserAuthentication.RequiredRoles
            }

            $azConnection = Invoke-BciabConnection @connectionParams
            $BciabProfile.Connections += $azConnection

            $context = ($BciabProfile.Connections | Where-Object { $_.ConnectionType -eq ([ConnectionType]::Azure) }).Context
            $BciabProfile.TenantId = $context.Tenant.Id
            $BciabProfile.TenantName = (Get-AzTenant -TenantId $BciabProfile.TenantId).DefaultDomain
            $BciabProfile.InitialTenant = (Get-AzTenant -TenantId $BciabProfile.TenantId).Domains | Where-Object { $_ -like "*.onmicrosoft.com" }

            #Previously connected to the AZ Module to minimise the user input requirements.
            #Now have an Access Token so will pass that to the Graph API module to authenticate and continue the process as it is a better method

            $url = ($Script:M365Settings.ResourceUris.TokenUrl -f $BciabProfile.TenantId)
            $body = @{
                scope      = $Script:M365Settings.ResourceUris.DefaultScopes
                grant_type = 'password'
                username   = $Credentials.UserName
                password   = $Credentials.GetNetworkCredential().Password
                client_id  = $Script:M365Settings.WellKnownClientIds.PowershellClient
            }

            $OAuthReq = Invoke-RestMethod -Uri $url -Method Post -Body $body
            $accessToken = ConvertTo-SecureString -String $OAuthReq.access_token -AsPlainText -Force

            $mgConnectionParams = @{
                ConnectionType     = [ConnectionType]::MgGraph
                AuthenticationType = [AuthenticationType]::AccessToken
                AccessToken        = $accessToken
            }

            $mgConnection = Invoke-BciabConnection @mgConnectionParams
            $BciabProfile.Connections += $mgConnection

            #Connect to Exchange Online
            $exoConnectionParams = @{
                ConnectionType     = [ConnectionType]::ExchangeOnline
                AuthenticationType = [AuthenticationType]::UserWithCredentials
                EnvironmentName    = [AzureEnvironment]::AzureCloud
                Credentials        = $Credentials
                Tenant             = $BciabProfile.TenantName
            }
            $exoConnection = Invoke-BciabConnection @exoConnectionParams
            $BciabProfile.Connections += $exoConnection

            Write-Host $Script:EmojiSuccess

            #Get the tenant configuration
            #region Get Config
            $configFile = Join-Path -Path $configPath -ChildPath $BciabProfile.ConfigurationSettingsFile

            if (-not (Test-Path -Path $configFile)) {
                throw ([System.IO.FileNotFoundException]::new(($Script:LocalData.Error_ConfigurationFileNotFound -f $configFile)))
            }
            $tenantConfig = Initialize-GenericJSONObject `
                -RawContent (Get-Content $configFile -Raw).Replace('$OrganizationName', $BciabProfile.TenantName)
            
            
            #endregion Get Config
            
            #region Breakglass setup
            #Create the Breakglass account including the Conditional Access exclusion group
            $bgCreationParams = @{
                Username           = $tenantConfig.EmergencyAccount.Username
                ExclusionGroupName = $tenantConfig.EmergencyAccount.ConditionalAccessExclusionGroup
                DomainName         = $BciabProfile.InitialTenant
            }
            Write-Host "`r`n" -NoNewline
            Write-Host $Script:LocalData.Verbose_CreatingEmergencyAccount `
                -NoNewline

            Invoke-BciabCreateBreakGlass @bgCreationParams `
                -ErrorAction SilentlyContinue `
                -ErrorVariable BciabBreakglassCreationError

            if ($BciabBreakglassCreationError.count -ge 1) {
                #This error will not throw an exception as the rest of BCIAB can still be done.
                Write-Host $Script:EmojiError
            } else {
                Write-Host $Script:EmojiSuccess
            }
            #endregion Breakglass setup

            #region Catch All mailbox setup
            #Create everything required for the Catch All Mailbox
            $catchAllParams = @{
                DistributionGroupName       = $tenantConfig.CatchAll.DynamicDistributionGroup.Name
                DistributionGroupAlias      = $tenantConfig.CatchAll.DynamicDistributionGroup.Alias
                DistributionGroupRecipients = $tenantConfig.CatchAll.DynamicDistributionGroup.IncludedRecipients
                MailboxName                 = $tenantConfig.CatchAll.Mailbox.Name
                MailboxAlias                = $tenantConfig.CatchAll.Mailbox.Alias
                MailboxForce                = $tenantConfig.CatchAll.Mailbox.Force
                MailboxShared               = $tenantConfig.CatchAll.Mailbox.Shared
                TransportRuleName           = $tenantConfig.CatchAll.TransportRule.Name
                TransportRuleFromScope      = $tenantConfig.CatchAll.TransportRule.FromScope
                TransportRuleRedirectTo     = $tenantConfig.CatchAll.TransportRule.RedirectMessageTo
                TransportRuleExceptIf       = $tenantConfig.CatchAll.TransportRule.ExceptIfSentToMemberOf
                TransportRuleStopProcessing = $tenantConfig.CatchAll.TransportRule.StopRuleProcessing
                TransportRuleMode           = $tenantConfig.CatchAll.TransportRule.Mode
                TransportRuleComments       = $tenantConfig.CatchAll.TransportRule.Comments
                TransportRuleErrorAction    = $tenantConfig.CatchAll.TransportRule.RuleErrorAction
                TransportRuleSenderLocation = $tenantConfig.CatchAll.TransportRule.SenderAddressLocation
            }

            if (-not [String]::IsNullOrEmpty($BciabProfile.TenantName)) {
                if ($BciabProfile.TenantName -notcontains 'onmicrosoft\.com') {
                    $catchAllParams.Add("DomainName", $BciabProfile.TenantName)
                }
            }

            Write-Host "`r`n" -NoNewline
            Write-Host $Script:LocalData.Verbose_CreatingCatchAllMailbox
            
            Invoke-BciabCreateCatchAll @catchAllParams `
                -ErrorAction SilentlyContinue `
                -ErrorVariable BciabMailboxCreationError

            if ($BciabMailboxCreationError.count -ge 1) {
                #This error will not throw an exception as the rest of BCIAB can still be done.
                Write-Host $Script:EmojiError
            } else {
                Write-Host $Script:EmojiSuccess
            }
            #endregion Catch All mailbox setup

        } catch {
            Write-Error $_
        }
    }
    end {
        try {
            Write-Host "`r`n" -NoNewline
            Write-Host $Script:LocalData.Verbose_ConnectionDisconnecting `
                -NoNewline

            foreach ($connectionProfile in $BciabProfile.Connections) {
                $connectionProfile.Disconnect()
            }

            Write-Host $Script:EmojiSuccess

            $Stopwatch.stop()
            $ElapsedTime = [math]::round($Stopwatch.Elapsed.TotalSeconds, 0)

            Write-Host ($Script:LocalData.Verbose_RunTime -f $ElapsedTime) `
                -ForegroundColor Green
        } catch {
            Write-Error $_
        } finally {
            Stop-Transcript
            [System.GC]::GetTotalMemory($true) | Out-Null
        }
    }
}