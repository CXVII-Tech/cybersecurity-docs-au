function Invoke-BciabConnection {
    <#
        .DESCRIPTION
            Creates a connection to Microsoft 365 using a specified connection type (e.g. Azure, Graph, ExchangeOnline, PnP, SharePoint)
        .PARAMETER ConnectionType
            Connection type to create, supported values: Azure, ExchangeOnline, MgGraph, SecurityCompliance
        .PARAMETER AuthenticationType
            Authentication method to use to ensure management of connections
        .PARAMETER EnvironmentName
            Azure Environment to connect to, supported values: AzureCloud, AzureGermanyCloud, AzureDOD, AzureUSGovernment, AzureChinaCloud
        .PARAMETER Credentials
            The credentials object to use for authentication
        .PARAMETER CertificateThumbprint
            Thumbprint of the certificate
        .PARAMETER CertificateName
            Certificate Name to be retrieved from the current user's certificate store
        .PARAMETER Certificate
            An X.509 certificate object
        .PARAMETER CertificatePath
            The path of certficate file in pkcs#12 format
        .PARAMETER CertificatePassword
            The password required to access the pkcs#12 certificate file
        .PARAMETER ApplicationId
            Application Id of the registered Azure application
        .PARAMETER ServicePrincipal
            Force a connection to use the ServicePrincipal
        .PARAMETER Tenant
            Tenant name or ID of the desired tenant
        .PARAMETER AccessToken
            Access Token for Graph or Azure Resource Manager connection
        .PARAMETER Identity
            Login using managed service identity in the current environment
        .PARAMETER Scopes
            An array of delegated permissions to consent to
        .PARAMETER RequiredRoles
            The role(s) to that must be assigned to the user otherwise fail the connection
    #>
    [CmdletBinding(DefaultParameterSetName = 'Interactive')]
    [OutputType([BciabConnection])]
    param (
        [Parameter(Mandatory)]
        [ConnectionType] $ConnectionType,

        [Parameter(Mandatory)]
        [AuthenticationType] $AuthenticationType,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Parameter(ParameterSetName = "ManagedService")]
        [AzureEnvironment] $EnvironmentName,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "UserWithCredentials")]
        [PSCredential] $Credentials,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [String] $CertificateThumbprint,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Alias("CertificateSubject")]
        [String] $CertificateName,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [X509Certificate] $Certificate,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [String] $CertificatePath,

        [Parameter(ParameterSetName = "ServicePrincipalCertificateFile")]
        [SecureString] $CertificatePassword,

        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias("AppId", "ClientId")]
        [String] $ApplicationId,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(ParameterSetName = "ClientAssertion")]
        [Switch] $ServicePrincipal,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Parameter(ParameterSetName = "AccessToken")]
        [Parameter(ParameterSetName = "ManagedService")]
        [Alias("Domain", "TenantId", "Organization")]
        [ValidateNotNullOrEmpty()]
        [String] $Tenant,

        [Parameter(Mandatory, ParameterSetName = "AccessToken")]
        [SecureString] $AccessToken,

        [Parameter(Mandatory, ParameterSetName = "ManagedService")]
        [Alias("MSI", "ManagedService")]
        [Switch] $Identity,

        [Parameter(ParameterSetName = "UserWithCredentials")]
        [String[]] $Scopes,

        [Parameter(ParameterSetName = "UserWithCredentials")]
        [String[]] $RequiredRoles
    )
    begin {
        if (-not $PSBoundParameters.ContainsKey('Confirm')) {
            $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
        }

        if (-not $PSBoundParameters.ContainsKey('WhatIf')) {
            $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
        }
    }
    process {
        try {
            if ($PSCmdlet.ParameterSetName -ne $AuthenticationType) {
                throw ($Script:LocalData.Error_IncorrectParameterSetToAuthenticationType -f $AuthenticationType)
            }

            $connectionParams = @{}
            foreach ($parameter in $PSBoundParameters.GetEnumerator()) {
                $connectionParams.Add($parameter.Key, $parameter.Value)
            }

            $Connection = [BciabConnection]::New($connectionParams)

            $Connection.Connect()

            return $Connection
        } catch {
            $logMsg = @{
                MessageData             = ($Script:LocalData.Error_Connection -f $ConnectionType)
                ConsoleMessage          = $Script:EmojiError
                CallStack               = (Get-PSCallStack | Select-Object -First 1)
                LogLevel                = "Error"
                Tags                    = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
                DifferentConsoleMessage = $true
            }

            Write-LogEntry @logMsg

            $logMsg.MessageData = $_
            Write-LogEntry @logMsg

            if ($Connection.Connected) {
                $Connection.Disconnect()
            }

            throw
        }
    }
}