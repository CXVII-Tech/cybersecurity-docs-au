function Invoke-BciabCreateCatchAll {
    <#
    .SYNOPSIS
        Creates a Catch All Mailbox within Exchange Online.
    .DESCRIPTION
        Creates a Catch All Mailbox, Dynamic Distribution Group, and Transport Rule within Exchange Online
        The Catch All Mailbox will capture all email messages sent to the domain.
        The Dynamic Group ensures that as mailboxes are created for use by user accounts or groups, mail will be instead automatically directed to the appropriate mailbox
        rather than captured in the catch all.
        It is important to note, that  the catch all mailbox will also capture spam and phishing mail. As such it, only a limited set of users should have access.
    .PARAMETER Path
        The path for the configuration file
    .PARAMETER FileName
        The name of the configuration file
    .PARAMETER DomainName
        The domain name for the organisation, not the subdomain for the onmicrosoft.com domain.
    .PARAMETER DistributionGroupName
        The DistributionGroupName parameter specifies the unique name for the distribution group.
        Maximum of 64 characters
    .PARAMETER DistributionGroupAlias
        The DistributionGroupAlias or mail nickname for the distribution group.
        Maximum of 64 characters.
    .PARAMETER DistributionGroupRecipients
        The DistributionGroupRecipients parameter specifies a filter based on the recipient type.
        Valid values are:
            * AllRecipients: This value can be used only by itself.
            * MailboxUsers
            * MailContacts
            * MailGroups
            * MailUsers
            * Resources: This value indicates room or equipment mailboxes.
    .PARAMETER MailboxAlias
        The Exchange Alias or mail nickname for the mailbox.
        Maximum of 64 characters.
    .PARAMETER MailboxName
        The unique name for the mailbox.
        Maximum of 64 characters.
    .PARAMETER MailboxForce
        When set, hides warning and confirmation messages when creating the mailbox within Exchange Online.
    .PARAMETER MailboxShared
        When set, creates a shared mailbox allowing multiple users to access mailbox contents.
        The mailbox will not be associated with any users that can log on and will instead be associated with a disabled user account.
    .PARAMETER TransportRuleFromScope
        Specifies an exception or part of an exception for the rule.
        Valid values are:
            * InOrganization: Message was sent or received over an authenticated connection and send meets defined criteria.
            * NotInOrganization: Sender's email address no in accepted domain.
    .PARAMETER TransportRuleRedirectTo
        Specifies a rule action that redirects messages to the specified recipients.
        Any value that uniquely identifies the recipient can be used.
    .PARAMETER TransportRuleExceptIf
        Specifies an exception that looks for messages sent to members of groups so messages do not route to the Catch All mailbox when true
    .PARAMETER TransportRuleName
        The Name parameter specifies the unique name for the associated Catch All Transport rule.
        The maximum length is 64 characters.
    .PARAMETER TransportRuleStopProcessing
        Specifies an action that will stop processing more rules.
        For the Catch All mailbox it is recommended to leave this set to 'false'.
    .PARAMETER TransportRuleMode
        The Mode parameter specifies how the rule operates. Valid values are:
            * Audit: The actions that the rule would have taken are written to the message tracking log, but no action that impacts message delivery is taken on the message.
            * AuditAndNotify: The actions that the rule would have taken are written to the message tracking log, but no action that impacts message delivery is taken on the message. Additional actions are taken to generate a notification.
            * Enforce: All actions specified in the rule are taken.
    .PARAMETER TransportRuleComments
        Specifies descriptive text for the rule. Maximum length is 1024 characters.
    .PARAMETER TransportRuleErrorAction
        The RuleErrorAction parameter specifies what to do if rule processing can't be completed on messages. Valid values are:
            * Ignore: The message is sent anyway
            * Defer: The message is deferred so the rules engine can attempt to process the message again.
    .PARAMETER TransportRuleSenderLocation
        The SenderAddressLocation parameter specifies where to look for sender addresses in conditions and exceptions that examine sender email addresses. Valid values are:
            * Header: Only examine senders in the message headers. For example, in on-premises Exchange the the From, Sender, or Reply-To fields. In Exchange Online, the From field only. This is the default value, and is the way rules worked before Exchange 2013 Cumulative Update 1 (CU1).
            * Envelope: Only examine senders from the message envelope (the MAIL FROM value that was used in the SMTP transmission, which is typically stored in the Return-Path field).
            * HeaderOrEnvelope: Examine senders in the message header and the message envelope.
    .EXAMPLE
        Invoke-BciabCreateCatchAll -Domain "contoso.com"
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium', DefaultParameterSetName = "AllConfig")]
    param(
        [Parameter(Mandatory, ParameterSetName = "AcceptedDomainConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [String] $DomainName,

        [Parameter(Mandatory, ParameterSetName = "DistributionGroupConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateLength(1, 64)]
        [String] $DistributionGroupName,

        [Parameter(Mandatory, ParameterSetName = "DistributionGroupConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateLength(1, 64)]
        [String] $DistributionGroupAlias,

        [Parameter(Mandatory, ParameterSetName = "DistributionGroupConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateSet("AllRecipients", "MailboxUsers", "MailContacts", "MailGroups", "MailUsers", "Resources", IgnoreCase)]
        [String] $DistributionGroupRecipients = "MailboxUsers",

        [Parameter(Mandatory, ParameterSetName = "MailboxConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateLength(1, 64)]
        [String] $MailboxAlias,

        [Parameter(Mandatory, ParameterSetName = "MailboxConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateLength(1, 64)]
        [String] $MailboxName,

        [Parameter(Mandatory, ParameterSetName = "MailboxConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [Switch] $MailboxForce,

        [Parameter(Mandatory, ParameterSetName = "MailboxConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [Switch] $MailboxShared,

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateLength(1, 64)]
        [String] $TransportRuleName,

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateSet("InOrganization", "NotInOrganization", IgnoreCase)]
        [String] $TransportRuleFromScope = "NotInOrganization",

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [String] $TransportRuleRedirectTo,

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [String] $TransportRuleExceptIf,

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [Switch] $TransportRuleStopProcessing = $false,

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateSet("Audit", "AuditAndNotify", "Enforce", IgnoreCase)]
        [String] $TransportRuleMode = "Enforce",

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateLength(1, 1024)]
        [String] $TransportRuleComments,

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateSet("Ignore", "Defer", IgnoreCase)]
        [String] $TransportRuleErrorAction = "Ignore",

        [Parameter(Mandatory, ParameterSetName = "TransportRuleConfig")]
        [Parameter(ParameterSetName = "AllConfig")]
        [ValidateSet("Header", "Envelope", "HeaderOrEnvelope", IgnoreCase)]
        [String] $TransportRuleSenderLocation = "Header"
    )
    begin {
        if (-not $PSBoundParameters.ContainsKey('Confirm')) {
            $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
        }

        if (-not $PSBoundParameters.ContainsKey('WhatIf')) {
            $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
        }
    }
    process {
        try {
            #Create a dynamic distribution list for all valid users
            #region Dynamic Distribution Group
            $shouldProcessMessage = ($Script:LocalData.ShouldProcess_DynamicGroupNewMessage -f $DistributionGroupName)
            $shouldProcessOperation = $Script:LocalData.ShouldProcess_DynamicGroupNew

            if ($PSCmdlet.ShouldProcess($shouldProcessMessage, $DistributionGroupName, $shouldProcessOperation)) {

                $dynamicGroupParams = $null
                switch ($PSCmdlet.ParameterSetName) {
                    "DistributionGroupConfig" {
                        $dynamicGroupParams = @{
                            Name               = $DistributionGroupName
                            Alias              = $DistributionGroupAlias
                            IncludedRecipients = $DistributionGroupRecipients
                        }
                    }
                    "AllConfig" {
                        if (-not (
                                [String]::IsNullOrEmpty($DistributionGroupName) -and
                                [String]::IsNullOrEmpty($DistributionGroupAlias) -and
                                [String]::IsNullOrEmpty($DistributionGroupRecipients))) {

                            $dynamicGroupParams = @{
                                Name               = $DistributionGroupName
                                Alias              = $DistributionGroupAlias
                                IncludedRecipients = $DistributionGroupRecipients
                            }
                        }
                    }
                }

                if ($null -ne $dynamicGroupParams) {
                    $dynamicGroup = New-DynamicDistributionGroup @dynamicGroupParams `
                        -ErrorAction SilentlyContinue `
                        -ErrorVariable CatchAllCreationError

                    if ($CatchAllCreationError.count -ge 1) {
                        $logMsg = @{
                            MessageData = ($Script:LocalData.Error_NewMailboxDynamicDistributionGroup -f $CatchAllCreationError)
                            CallStack   = (Get-PSCallStack | Select-Object -First 1)
                            LogLevel    = "Error"
                            Tags        = @($Script:LocalData.Tag_CreateCatchAll, $Script:LocalData.Tag_Error)
                        }
                        Write-LogEntry @logMsg

                        throw $CatchAllCreationError
                    } else {
                        Write-Host $Script:LocalData.Verbose_NewMailboxDynamicDistributionGroup `
                            -ForegroundColor Green
                    }
                }
            }
            #endregion Dynamic Distribution Group

            #Create a shared mailbox to receive the errant messages
            #region Mailbox
            $shouldProcessMessage = ($Script:LocalData.ShouldProcess_MailboxNewMessage -f $MailboxName)
            $shouldProcessOperation = $Script:LocalData.ShouldProcess_MailboxNew

            if ($PSCmdlet.ShouldProcess($shouldProcessMessage, $MailboxName, $shouldProcessOperation)) {
                $mailboxParams = $null
                switch ($PSCmdlet.ParameterSetName) {
                    "MailboxConfig" {
                        $mailboxParams = @{
                            Name   = $MailboxName
                            Alias  = $MailboxAlias
                            Shared = $MailboxShared
                            Force  = $MailboxForce
                        }
                    }
                    "AllConfig" {
                        if (-not (
                                [String]::IsNullOrEmpty($MailboxName) -and
                                [String]::IsNullOrEmpty($MailboxShared))) {

                            $mailboxParams = @{
                                Name   = $MailboxName
                                Shared = $MailboxShared
                            }

                            if ([String]::IsNullOrEmpty($MailboxForce)) {
                                $mailboxParams.Add("Force", $false)
                            } else {
                                $mailboxParams.Add("Force", $MailboxForce)
                            }

                            if ([String]::IsNullOrEmpty($MailboxAlias)) {
                                $mailboxParams.Add("Alias", $MailboxName)
                            } else {
                                $mailboxParams.Add("Alias", $MailboxAlias)
                            }
                        }
                    }
                }

                if ($null -ne $mailboxParams) {
                    $mailbox = New-Mailbox @mailboxParams `
                        -ErrorAction SilentlyContinue `
                        -ErrorVariable CatchAllCreationError

                    if ($CatchAllCreationError.count -ge 1) {
                        $logMsg = @{
                            MessageData = ($Script:LocalData.Error_NewMailbox -f $CatchAllCreationError)
                            CallStack   = (Get-PSCallStack | Select-Object -First 1)
                            LogLevel    = "Error"
                            Tags        = @($Script:LocalData.Tag_CreateCatchAll, $Script:LocalData.Tag_Error)
                        }
                        Write-LogEntry @logMsg

                        throw $CatchAllCreationError
                    } else {
                        Write-Host $Script:LocalData.Verbose_NewMailboxObject `
                            -ForegroundColor Green
                    }
                }
            }
            #endregion Mailbox

            #Create a transport rule to redirect  messages
            #region Transport Rule
            $shouldProcessMessage = ($Script:LocalData.ShouldProcess_TransportRuleNewMessage -f $TransportRuleName)
            $shouldProcessOperation = $Script:LocalData.ShouldProcess_TransportRuleNew
            if ($PSCmdlet.ShouldProcess($shouldProcessMessage, $TransportRuleName, $shouldProcessOperation)) {
                $transportRuleParams = $null
                switch ($PSCmdlet.ParameterSetName) {
                    "TransportRuleConfig" {
                        $transportRuleParams = @{
                            Name                   = $TransportRuleName
                            Comments               = $TransportRuleComments
                            FromScope              = $TransportRuleFromScope
                            RedirectMessageTo      = $TransportRuleRedirectTo
                            ExceptIfSentToMemberOf = $TransportRuleExceptIf
                            StopRuleProcessing     = $TransportRuleStopProcessing
                            Mode                   = $TransportRuleMode
                            RuleErrorAction        = $TransportRuleErrorAction
                            SenderAddressLocation  = $TransportRuleSenderLocation
                        }
                    }
                    "AllConfig" {
                        if (-not (
                                [String]::IsNullOrEmpty($TransportRuleName) -and
                                [String]::IsNullOrEmpty($TransportRuleRedirectTo) -and
                                [String]::IsNullOrEmpty($TransportRuleExceptIf))) {

                            $transportRuleParams = @{
                                Name                   = $TransportRuleName
                                Comments               = $TransportRuleComments
                                FromScope              = $TransportRuleFromScope
                                RedirectMessageTo      = $TransportRuleRedirectTo
                                ExceptIfSentToMemberOf = $TransportRuleExceptIf
                                StopRuleProcessing     = $TransportRuleStopProcessing
                                Mode                   = $TransportRuleMode
                                RuleErrorAction        = $TransportRuleErrorAction
                                SenderAddressLocation  = $TransportRuleSenderLocation
                            }
                        }
                    }
                }

                if ($null -ne $transportRuleParams) {
                    $transportRule = New-TransportRule @transportRuleParams `
                        -ErrorAction SilentlyContinue `
                        -ErrorVariable CatchAllCreationError

                    if ($CatchAllCreationError.count -ge 1) {
                        $logMsg = @{
                            MessageData = ($Script:LocalData.Error_NewTransportRule -f $CatchAllCreationError)
                            CallStack   = (Get-PSCallStack | Select-Object -First 1)
                            LogLevel    = "Error"
                            Tags        = @($Script:LocalData.Tag_CreateCatchAll, $Script:LocalData.Tag_Error)
                        }
                        Write-LogEntry @logMsg

                        throw $CatchAllCreationError
                    } else {
                        Write-Host $Script:LocalData.Verbose_NewTransportRule `
                            -ForegroundColor Green
                    }
                }
            }
            #endregion Transport Rule

            #Disabling Directory-Based Edge Blocking
            #region Set Accepted Domain
            $shouldProcessMessage = ($Script:LocalData.ShouldProcess_SetAcceptedDomainMessage -f $DomainName)
            $shouldProcessOperation = $Script:LocalData.ShouldProcess_SetAcceptedDomain

            if ($PSCmdlet.ShouldProcess($shouldProcessMessage, $DomainName, $shouldProcessOperation)) {
                if (-not [String]::IsNullOrEmpty($DomainName)) {
                    $acceptedDomainParams = @{
                        Identity   = $DomainName
                        DomainType = "InternalRelay"
                    }

                    $acceptedDomain = Set-AcceptedDomain @acceptedDomainParams `
                        -ErrorVariable CatchAllCreationError

                    if ($CatchAllCreationError.count -ge 1) {
                        $logMsg = @{
                            MessageData = ($Script:LocalData.Error_SetAcceptedDomain -f $CatchAllCreationError)
                            CallStack   = (Get-PSCallStack | Select-Object -First 1)
                            LogLevel    = "Error"
                            Tags        = @($Script:LocalData.Tag_CreateCatchAll, $Script:LocalData.Tag_Error)
                        }
                        Write-LogEntry @logMsg

                        throw $CatchAllCreationError
                    } else {
                        Write-Host $Script:LocalData.Verbose_SetAcceptedDomain `
                            -ForegroundColor Green
                    }
                }
            }
            #endregion Set Accepted Domain
        } catch {
            $logMsg = @{
                MessageData = ($Script:LocalData.Warning_DependencyUpdateFailure -f $ModuleName, $RequiredVersion)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Dependencies, $Script:LocalData.Tag_Information)
            }

            Write-LogEntry @logMsg

            if ($null -ne $dynamicGroup) {
                Remove-DynamicDistributionGroup -Identity $dynamicGroup.Identity `
                    -ErrorAction SilentlyContinue
            }

            if ($null -ne $mailbox) {
                Remove-Mailbox -Identity $mailbox.Identity `
                    -ErrorAction SilentlyContinue
            }

            if ($null -ne $transportRule) {
                Remove-TransportRule -Identity $transportRule.Identity `
                    -ErrorAction SilentlyContinue
            }

            if ($null -ne $acceptedDomain) {
                if (-not [String]::IsNullOrEmpty($DomainName)) {
                    Remove-AcceptedDomain $DomainName `
                        -ErrorAction SilentlyContinue
                }
            }
        }
    }
}