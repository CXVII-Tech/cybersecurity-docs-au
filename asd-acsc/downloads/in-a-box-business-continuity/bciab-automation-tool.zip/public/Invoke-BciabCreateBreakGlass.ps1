function Invoke-BciabCreateBreakGlass {
    <#
    .SYNOPSIS
        Creates a break glass account and a group for excluding the account from Conditional Access
    .DESCRIPTION
        Creates a break glass account and a group within Azure Active Directory.
        A random password is generated and returned to the user console after creation of the account
        The account is added as a member to the Global Administrator role and also as a member of the
        the new group, which should be used for the purpose of excluding Breakglass from Conditional Access.
    .PARAMETER Username
        The Username that will be given to the new account. If provided with the domain name (e.g. breakglass@contoso.onmicrosoft.com), the function will strip the domain.
    .PARAMETER Path
        The path for the configuration file
    .PARAMETER FileName
        The name of the configuration file
    .PARAMETER DomainName
        The tenant name for the organisation provided as a subdomain of the onmicrosoft.com domain.
        Break glass accounts need to be created against the organisations 'onmicrosoft.com' domain as opposed to the organisations domain.
    .PARAMETER ExclusionGroupName
        The name to give to the group in which the break glass will be added
    .EXAMPLE
        Invoke-BciabBreakGlassCreation -Username "Breakglass" -ExclusionGroupName "grp-Conditional_Access_Exclude" -DomainName "contoso.onmicrosoft.com"
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory)]
        [String] $Username,

        [Parameter()]
        [String] $ExclusionGroupName,

        [Parameter(Mandatory)]
        [ValidatePattern("(^|^[^:]+:\/\/|[^\.]+\.)onmicrosoft\.com")]
        [String] $DomainName
    )
    begin {
        if (-not $PSBoundParameters.ContainsKey('Confirm')) {
            $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
        }

        if (-not $PSBoundParameters.ContainsKey('WhatIf')) {
            $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
        }

        $context = Get-MgContext `
            -ErrorAction SilentlyContinue

        if ($null -eq $context) {
            throw $Script:LocalData.Exception_NotConnected
        }
    }
    process {
        try {
            $upn = $Username + '@' + $DomainName

            $bgUsr = Get-MgUser -Filter ($Script:LocalData.Filter_DisplayName -f $upn)

            if ($null -eq $bgUsr) {
                $bgPassword = Get-NewPassword

                $usrPasswordProfile = @{
                    ForceChangePasswordNextSignIn        = $false
                    ForceChangePasswordNextSignInWithMfa = $false
                    Password                             = $bgPassword
                }

                $bgUsrParams = @{
                    DisplayName       = $Username
                    AccountEnabled    = $true
                    ShowInAddressList = $false
                    UserPrincipalName = $upn
                    PasswordProfile   = $usrPasswordProfile
                    MailNickname      = $Username
                }
                $shouldProcessOperation = $Script:LocalData.ShouldProcess_NewMgUser
                $shouldProcessMessage = ($Script:LocalData.ShouldProcess_NewMgUserMessage -f $Username)

                if ($PSCmdlet.ShouldProcess($shouldProcessMessage, $shouldProcessOperation)) {
                    $bgUsr = New-MgUser @bgUsrParams `
                        -ErrorAction SilentlyContinue `
                        -ErrorVariable UserCreationError

                    if ($UserCreationError.count -ge 1) {
                        throw $UserCreationError
                    }

                    $bgUpdUsrParams = @{
                        UserId           = $bgUsr.Id
                        PasswordPolicies = "DisablePasswordExpiration"
                    }

                    Update-MgUser @bgUpdUsrParams `
                        -ErrorAction SilentlyContinue `
                        -ErrorVariable UserUpdateError

                    if ($UserUpdateError.count -ge 1) {
                        $logMsg = @{
                            MessageData = $Script:LocalData.Error_UnableToUpdateBreakGlassAccount
                            CallStack   = (Get-PSCallStack | Select-Object -First 1)
                            LogLevel    = "Warning"
                            Tags        = @($Script:LocalData.Tag_CreateBreakglass, $Script:LocalData.Tag_Warning)
                        }

                        Write-LogEntry @logMsg
                    }
                }

                #Prompt the user with the credentials for the new break glass account
                Add-Type -AssemblyName PresentationCore, PresentationFramework
                $MessageIcon = [System.Windows.MessageBoxImage]::Error
                $MessageTitle = $Script:LocalData.UI_BreakglassCredentialsTitle
                $MessageBody = ($Script:LocalData.UI_BreakglassCredentials -f $bgUsr.UserPrincipalName, $bgPassword)
                $ButtonType = [System.Windows.MessageBoxButton]::OK

                [System.Windows.MessageBox]::Show($MessageBody, $MessageTitle, $ButtonType, $MessageIcon)
            }

            $caExcGroup = Get-MgGroup -Filter (($Script:LocalData.Filter_DisplayName -f $ExclusionGroupName))
            if ($null -eq $caExcGroup) {
                #Create a Conditional Access Exclusion Group & add the new break glass account to group
                $grpParams = @{
                    DisplayName        = $ExclusionGroupName
                    IsAssignableToRole = $false
                    MailEnabled        = $false
                    SecurityEnabled    = $true
                    MailNickname       = $ExclusionGroupName
                }

                $shouldProcessOperation = $Script:LocalData.ShouldProcess_NewMgGroup
                $shouldProcessMessage = ($Script:LocalData.ShouldProcess_NewMgGroupMessage -f $ExclusionGroupName)

                if ($PSCmdlet.ShouldProcess($shouldProcessMessage, $shouldProcessOperation)) {

                    $caExcGroup = New-MgGroup @grpParams `
                        -ErrorAction SilentlyContinue `
                        -ErrorVariable GroupCreationError

                    if ($GroupCreationError.count -ge 1) {
                        $logMsg = @{
                            MessageData = ($Script:LocalData.Error_ExclusionGroup -f $GroupCreationError)
                            CallStack   = (Get-PSCallStack | Select-Object -First 1)
                            LogLevel    = "Warning"
                            Tags        = @($Script:LocalData.Tag_CreateBreakglass, $Script:LocalData.Tag_Warning)
                        }

                        Write-LogEntry @logMsg
                    }
                }
                if ($null -ne $caExcGroup) {
                    $grpMember = @{
                        GroupId           = $caExcGroup.Id
                        DirectoryObjectId = $bgUsr.Id
                    }
                    New-MgGroupMember @grpMember
                } else {
                    $logMsg = @{
                        MessageData = ($Script:LocalData.Error_ExclusionGroup -f $GroupCreationError)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Warning"
                        Tags        = @($Script:LocalData.Tag_CreateBreakglass, $Script:LocalData.Tag_Warning)
                    }

                    Write-LogEntry @logMsg
                }
            }
        } catch {
            $logMsg = @{
                MessageData = $Script:LocalData.Error_UnableToCreateBreakGlassAccount
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_CreateBreakglass, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg
        }
    }
}