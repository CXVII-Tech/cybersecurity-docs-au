﻿function Invoke-BciabGroupCreation {
    <#
    .DESCRIPTION
        Creates a security group.
    .PARAMETER Groupname
        The name for the group. Maximum length of 256 characters.
    .PARAMETER MailEnabled
        Specifies whether the gorup is enabled to receive mail.
    .EXAMPLE
        Invoke-BciabGroupCreation -Groupname "grp-Conditional_Access_Exclude" -MailEnabled
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateLength(1, 256)]
        [String] $GroupName,

        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [Switch] $MailEnabled
    )
    begin {
        if (-not $PSBoundParameters.ContainsKey('Confirm')) {
            $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
        }

        if (-not $PSBoundParameters.ContainsKey('WhatIf')) {
            $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
        }

        #TODO: Adjust to connect if not connected instead of throwing an error
        $context = Get-MgContext `
            -ErrorAction SilentlyContinue

        if ($null -eq $context) {
            throw $Script:LocalData.Exception_NotConnected
        }
    }
    process {
        try {
            $group = Get-MgGroup -Filter (($Script:LocalData.Filter_DisplayName -f $GroupName))
            if ($null -eq $group) {
                #Create a Conditional Access Exclusion Group & add the new break glass account to group
                $grpParams = @{
                    DisplayName     = $GroupName
                    MailNickname    = $GroupName
                    SecurityEnabled = $true
                    MailEnabled     = $MailEnabled
                }

                $group = New-MgGroup @grpParams `
                    -ErrorAction SilentlyContinue `
                    -ErrorVariable GroupCreationError
            }

            if ($GroupCreationError.count -ge 1) {
                $logMsg = @{
                    MessageData = $Script:LocalData.Error_GroupCreation
                    CallStack   = (Get-PSCallStack | Select-Object -First 1)
                    LogLevel    = "Error"
                    Tags        = @($Script:LocalData.Tag_GroupCreation, $Script:LocalData.Tag_Error)
                }

                Write-LogEntry @logMsg

                throw $GroupCreationError
            }
        } catch {
            $logMsg = @{
                MessageData = $_
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_GroupCreation, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg
        }
    }
}