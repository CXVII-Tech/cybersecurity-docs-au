<#
    .SYNOPSIS
        Business Continuity in a Box (BCiaB) is a tool to assist organisations to rapidly provision a secure Microsoft 365 tenant
        including Exchange Online and associated security controls in response to a business continuity event affecting an organisations information technology services.
    .DESCRIPTION
        Business Continuity in a Box (BCiaB) is a tool to assist organisations rapidly configure a new Microsoft 365 tenant in response to a business continuity event which affects information technology services.
        This tool will perform the following actions:

        1.  Load requisite modules necessary for the tool to update the Microsoft 365 tenant.
            NOTE:   Whilst it would be beneficial to use Microsoft365DSC, it requires running as administrator.
                    Because this script may be run by non technical users, it is preferable to reduce as many steps as possible and therefore not need Run As Administrator.
        2.  Create a new emergency account (BreakGlass) to be used in situations where no administrators are able to log in to their account.
        3.  Create a temporary 'Catch All' mailbox to ensure that all email sent to any organisation email address is captured.

        NOTE: Other than the emeregency break glass account, this tool will not create additional organisation user accounts.
        Creation of user accounts and assignment of users to an appropriate Microsoft 365 licence is the responsibility of the organisation.
        When new user accounts are added to the Microsoft 365 tenant, the 'Catch All' mailbox will be automatically updated so that email sent to the
        new user will be directed to the relevant user email mailbox and not be captured by the 'Catch All mailbox.
    .NOTES
        Author		: Australian Cyber Security Centre
        File Name	: BCiaB.ps1
        Version     : 0.9
    .PARAMETER NoClean
        At the end of implementing the script functions, do not clean up created objects.
    .PARAMETER WhatIf
        Provides a summary of the actions that will be taken which includes the changes that will be made to the tenant, but does not perform the actual actions.
    .PARAMETER Confirm
        Will prompt for confirmation before performing actions that will alter the tenant
   .EXAMPLE
        BCiaB.ps1
    .EXAMPLE
        BCiaB.ps1 -NoClean

        Runs all of the script to setup the Microsoft 365 tenant; however, it does not delete the Azure Application and associated certificate file, and does not remove installed PowerShell Modules.
    .EXAMPLE
        BCiaB.ps1 -WhatIf
    .EXAMPLE
        BCiaB.ps1 -Confirm
#>

[CmdletBinding()]
param (
    [Parameter()]
    [Switch] $NoClean
)

Clear-Host
$Host.UI.RawUI.WindowTitle = "Business Continuity in a Box"

$BCiaBManifestFile = Join-Path -Path $PSScriptRoot -ChildPath 'BCiaB.psd1'
if (Test-Path -Path $BCiaBManifestFile) {
    $BCiaBManifest = Import-PowerShellDataFile ($BCiaBManifestFile)

    $ModuleVersion = $BCiaBManifest.ModuleVersion
    Write-Output("Welcome to Business Continuity in a Box v$ModuleVersion.")
} else {
    Write-Output "Unable to find the required data file, BCiaB.psd1. Please check all contents of the BCiaB package have been downloaded and extracted and then run again."
    exit
}

$BCiaBModule = Join-Path -Path $PSScriptRoot -ChildPath 'BCiaB.psm1'

if (Test-Path -Path $BCiaBModule) {
    Import-Module $BCiaBModule -Force
} else {
    Write-Output "Unable to find the required manifest file, BCiaB.psm1. Please check all contents of the BCiaB package have been downloaded and extracted and then run again."
    exit
}

Invoke-BCiaB $PSBoundParameters