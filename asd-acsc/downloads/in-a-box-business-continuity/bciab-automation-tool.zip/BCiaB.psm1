<#
   .DESCRIPTION
   A detailed description of the function.
#>
[CmdletBinding()]

#Create the localisation variable from the relevant culture
$LocalizedDataParams = @{
    BaseDirectory   = 'localization'
    BindingVariable = 'LocalData'
    FileName        = 'resource.strings.psd1'
}
Import-LocalizedData @LocalizedDataParams

#Import the enums, classes, public, and private function definition file and dot source
$ModulesList = @{
    enums   = '/enums/'
    classes = '/classes/'
    private = '/private/'
    public  = '/public/'
}

foreach ($module in $ModulesList.GetEnumerator()) {
    $metadata = [System.IO.File]::GetAttributes(("{0}{1}" -f $PSScriptRoot, $module.value))
    if ($metadata -band [System.IO.FileAttributes]::Directory) {
        $all_files = Get-ChildItem -Recurse -Path ("{0}{1}" -f $PSScriptRoot, $module.value) -File -Include "*.ps1" -ErrorAction SilentlyContinue
        if ($null -ne $all_files) {
            foreach ($mod in $all_files) {
                Write-Verbose ("Loading {0} module" -f $mod.FullName)
                . $mod.FullName
            }
        }
    } else {
        Write-Verbose ("Loading {0} module" -f $module.Name)
        $tmp_module = ("{0}{1}" -f $PSScriptRoot, $module.value)
        . $tmp_module.ToString()
    }
}

#Assign PSScriptRoot to the variable ScriptPath for use during execution
New-Variable -Name ScriptPath -Value $PSScriptRoot -Scope Script -Force

#Assign Emojis to Script level variables for use in console messages
$successEmoji = [char]::ConvertFromUtf32(0x2705)
$errorEmoji = [char]::ConvertFromUtf32(0x274C)
$warningEmoji = [char]::ConvertFromUtf32(0x26A0)
New-Variable -Name EmojiSuccess -Value $successEmoji -Scope Script -Force
New-Variable -Name EmojiError -Value $errorEmoji -Scope Script -Force
New-Variable -Name EmojiWarning -Value $warningEmoji -Scope Script -Force

#Dot source the orchestration script
$bciab = Join-Path -Path $PSScriptRoot -ChildPath "Invoke-BCiaB.ps1"
. $bciab