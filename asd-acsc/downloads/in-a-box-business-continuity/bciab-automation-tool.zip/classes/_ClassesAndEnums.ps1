﻿# All classes and enums are defined in this single file for the moment.
# PowerShell does not build the code and therefore we get Script Analysis warnings when the code blocks are in their own files.

class BciabConnection {
    [AuthenticationType] $AuthenticationType
    [AzureEnvironment] $EnvironmentName
    [Boolean] $Connected = $false
    [DateTime] $ConnectedDateTime
    [ConnectionType] $ConnectionType

    BciabConnection() {}

    BciabConnection([Hashtable] $InputProperties = @{}) {
        foreach ($property in $InputProperties.GetEnumerator()) {
            if ([bool]($this.PSobject.Properties.name -contains $property.Name)) {
                $this.($property.Name) = $property.Value
            } else {
                $memberParams = @{
                    MemberType = "NoteProperty"
                    Name       = $property.Name
                    Value      = $property.Value
                }
                $this | Add-Member @memberParams
            }
        }
    }

    [void] Connect() {
        try {
            $connectionParams = @{}
            foreach ($parameter in $this.PSObject.Properties) {
                $connExclusionStrings = @("ConnectionType", "Connected", "ConnectedDateTime")
                if ($parameter.Name -notin $connExclusionStrings) {
                    $connectionParams.Add($parameter.Name, $parameter.Value)
                }
            }

            switch ($this.ConnectionType) {
                ([ConnectionType]::Azure) {
                    if (-not $this.Connected) {
                        $this.Connected = Connect-BciabAzure @connectionParams

                        if ($this.Connected) {
                            $context = Get-AzContext

                            $this | Add-Member `
                                -MemberType NoteProperty `
                                -Name  "Context" `
                                -Value $context

                            $this.ConnectedDateTime = [DateTime]::Now
                        }
                    }
                }
                ([ConnectionType]::ExchangeOnline) {
                    if (-not $this.Connected) {
                        $exchangeEnvironmentName = [ExchangeEnvironment]::O365Default
                        switch ($this.EnvironmentName) {
                        ([AzureEnvironment]::AzureCloud) {
                                $exchangeEnvironmentName = [ExchangeEnvironment]::O365Default
                            }
                        ([AzureEnvironment]::AzureGermanyCloud) {
                                $exchangeEnvironmentName = [ExchangeEnvironment]::O365GermanyCloud
                            }
                        ([AzureEnvironment]::AzureDOD) {
                                $exchangeEnvironmentName = [ExchangeEnvironment]::O365USGovDoD
                            }
                        ([AzureEnvironment]::AzureUSGovernment) {
                                $exchangeEnvironmentName = [ExchangeEnvironment]::O365USGovGCCHigh
                            }
                        ([AzureEnvironment]::AzureChinaCloud) {
                                $exchangeEnvironmentName = [ExchangeEnvironment]::O365China
                            }
                        }

                        $connectionParams.Add("ExchangeEnvironmentName", $exchangeEnvironmentName)
                        $connectionParams.Remove("EnvironmentName")

                        $this.Connected = Connect-BciabExchangeOnline @connectionParams
                    }
                }
                ([ConnectionType]::MgGraph) {
                    if (-not $this.Connected) {
                        $graphEnvironmentName = [GraphEnvironment]::Global
                        switch ($this.EnvironmentName) {
                        ([AzureEnvironment]::AzureCloud) {
                                $graphEnvironmentName = [GraphEnvironment]::Global
                            }
                        ([AzureEnvironment]::AzureGermanyCloud) {
                                $graphEnvironmentName = [GraphEnvironment]::Germany
                            }
                        ([AzureEnvironment]::AzureDOD) {
                                $graphEnvironmentName = [GraphEnvironment]::USGovDoD
                            }
                        ([AzureEnvironment]::AzureUSGovernment) {
                                $graphEnvironmentName = [GraphEnvironment]::USGovGCCHigh
                            }
                        ([AzureEnvironment]::AzureChinaCloud) {
                                $graphEnvironmentName = [GraphEnvironment]::China
                            }
                        }

                        if ($this.AuthenticationType -ne [AuthenticationType]::AccessToken) {
                            $connectionParams.Add("GraphEnvironmentName", $graphEnvironmentName)
                            $connectionParams.Remove("EnvironmentName")
                        } else {
                            $connectionParams.Remove("EnvironmentName")
                        }

                        $this.Connected = Connect-BciabMgGraph @connectionParams
                    }
                }
                ([ConnectionType]::SecurityCompliance) {}
            }
        } catch {
            $this.Connected = $false
            throw
        }
    }

    [void] Disconnect() {
        try {
            Disconnect-Tenant -ConnectionType $this.ConnectionType

            $this.Connected = $false
        } catch {
            throw
        }
    }
}
class BciabLogger {
    [String] $Name
    [LogOutputType[]] $Output
    [String] $Filename
    [String] $TranscriptLog
    [Boolean] $IncludeError
    [Boolean] $IncludeInformation
    [Boolean] $IncludeWarning
    [Boolean] $IncludeDebug
    [Boolean] $IncludeVerbose
    [String] $TypeName
    [String] $Command

    hidden Init() {

    }

    BciabLogger() {
        $this.Init()
    }

    BciabLogger([Hashtable] $InputProperties = @{}) {
        foreach ($property in $InputProperties.GetEnumerator()) {
            if ([bool]($this.PSobject.Properties.name -contains $property.Name)) {
                $this.($property.Name) = $property.Value
            }
        }
    }
}

class BciabProfile {
    [DateTime] $CreatedTime
    [String] $Version
    [String] $OutputPath
    [String] $TenantId
    [String] $TenantName
    [String] $InitialTenant
    [Hashtable] $UserAuthentication
    [Hashtable] $AzureApp
    [Hashtable] $VerboseOptions
    [PSCredential] $DebugUser
    [BciabConnection[]] $Connections
    [String] $ConfigurationSettingsFile
    [Hashtable] $EmergencyAccount
    [Hashtable] $DynamicDistributionGroup
    [Hashtable] $Mailbox
    [Hashtable] $TransportRule

    hidden Init() {
        $this.CreatedTime = [DateTime]::Now
        $this.Connections = @()
    }

    BciabProfile() {
        $this.Init()
    }

    BciabProfile([Hashtable] $InputProperties = @{}) {
        $this.Init()
        foreach ($property in $InputProperties.GetEnumerator()) {
            if ([bool]($this.PSobject.Properties.name -contains $property.Name)) {
                $this.($property.Name) = $property.Value
            }
        }
    }

    [void] UpdateAppConfig([String] $Key, [String] $Value) {
        if ($this.AzureApp.ContainsKey($key)) {
            $this.AzureApp[$key] = $value
        } else {
            $this.AzureApp.Add($key, $value)
        }

    }

    [BciabConnection] FindConnection([Hashtable] $InputProperties = @{}) {
        try {
            $tmpConnection = [BciabConnection]::New($InputProperties)

            return $this.Connections | Where-Object { $_ -in $tmpConnection }
        } catch {
            throw
        }
    }
}

enum ApplicationAuthType {
    Certificate
    Secret
}

enum AuthenticationType {
    AccessToken
    Interactive
    ManagedService
    ServicePrincipalWithSecret
    ServicePrincipalCertificate
    ServicePrincipalCertificateFile
    UserWithCredentials
}

enum AzureEnvironment {
    AzureCloud
    AzureGermanyCloud
    AzureDOD
    AzureUSGovernment
    AzureChinaCloud
}

enum ConnectionType {
    Azure
    ExchangeOnline
    MgGraph
    SecurityCompliance
}

enum ExchangeEnvironment {
    O365Default
    O365GermanyCloud
    O365China
    O365USGovGCCHigh
    O365USGovDod
}

enum GraphEnvironment {
    Global
    Germany
    USGovDoD
    USGovGCCHigh
    China
}

enum LogOutputType {
    console
    file
}

enum M365Service {
    AAD
    EXO
    Intune
    O365
    OD
    Planner
    PP
    SPO
    SC
    Teams
}