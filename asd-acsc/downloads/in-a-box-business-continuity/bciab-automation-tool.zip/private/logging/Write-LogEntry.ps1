function Write-LogEntry {
    <#
        .DESCRIPTION
            Writes an entry to the log file and console
        .PARAMETER Exception
            The Exception message to write
        .PARAMETER Message
            The message to format and write
        .PARAMETER Tags
            An  array of tags to apply to the message for additional formatting and ease of searching
        .PARAMETER Body
            The body of the message to write to file
        .PARAMETER ForegroundColor
            Foreground (text) colour of the message when writing to the console
        .PARAMETER BackgroundColor
            Background (highlight) colour of the message when writing to the console
        .PARAMETER CallStack
            The full call stack leading up to the entr y
        .PARAMETER LogLevel
            The configured level of logging to determine what to write to the console
        .PARAMETER FunctionName
            Name of the function which is creating the log entry
        .PARAMETER NoNewLine
            When set, does not add a line break at the end of the log entry
        .PARAMETER DifferentConsoleMessage
            When set, outputs just the message to the console as opposed to the formatted message.
    #>
    [CmdletBinding()]
    param
    (
        [Parameter(ParameterSetName = 'Exception')]
        [Exception] ${Exception},

        [Parameter(Mandatory)]
        [Alias('msg', 'MessageData')]
        [AllowEmptyString()]
        [AllowNull()]
        [Object] ${Message},

        [Parameter()]
        [String[]] ${Tags},

        [Parameter(HelpMessage = "Message body")]
        [Object] $Body,

        [Parameter(HelpMessage = "Foreground Color")]
        [ConsoleColor] $ForegroundColor = $Host.UI.RawUI.ForegroundColor,

        [Parameter(HelpMessage = "Background Color")]
        [ConsoleColor] $BackgroundColor = $Host.UI.RawUI.BackgroundColor,

        [Parameter(HelpMessage = "CallStack")]
        [System.Management.Automation.CallStackFrame] $CallStack,

        [Parameter()]
        [ValidateSet('Debug', 'Verbose', 'Error', 'Warning', 'Information')]
        [String] $LogLevel = 'Information',

        [Parameter()]
        [String] $ConsoleMessage,

        [Parameter()]
        [String] $FunctionName,

        [Parameter()]
        [Switch] $NoNewline,

        [Parameter()]
        [Switch] $DifferentConsoleMessage

    )
    begin {
        try {
            $newPsboundParams = [ordered]@{}

            $typeName = $Script:BciabLogger.TypeName
            $cmdName = ($Script:BciabLogger.Command -f $LogLevel)
            $MetaData = New-Object -TypeName $typeName (Get-Command -Name $cmdName)

            if ($null -ne $MetaData) {
                $param = $MetaData.Parameters.Keys

                foreach ($parameter in $param.GetEnumerator()) {
                    if ($PSBoundParameters.ContainsKey($parameter)) {
                        $newPsboundParams.Add($parameter, $PSBoundParameters[$parameter])
                    }
                }
            }

            #Get CallStack Information
            $tmpCommand = (Get-PSCallStack | Select-Object -Skip 1 | Select-Object -First 1).Command

            if ($null -ne $callStack -and $callStack.Command.Length -gt 0) {
                $Command = $callStack.Command;
            } elseif ($null -ne $callStack -and $callStack.FunctionName.Length -gt 0) {
                $Command = $callStack.FunctionName;
            } elseif ($FunctionName) {
                $Command = $FunctionName
            } elseif ($tmpCommand) {
                $Command = $tmpCommand
            } else {
                $Command = 'unknown';
            }

            #Check Log Level
            if (-not $PSBoundParameters.ContainsKey('LogLevel')) {
                $PSBoundParameters.Add('LogLevel', 'Information')
            }

            #Check if verbose and debug variables are present
            if ($null -ne (Get-Variable -Name BciabLogger -ErrorAction Ignore)) {
                #override default option
                $PSBoundParameters.Verbose = $Script:BciabLogger.includeVerbose
                $PSBoundParameters.Debug = $Script:BciabLogger.includeDebug
                if ($Script:BciabLogger.includeVerbose -eq $true) {
                    $informationAction = "Continue"
                } else {
                    $informationAction = "SilentlyContinue"
                }
                if ($Script:BciabLogger.includeDebug -eq $true) {
                    $informationAction = "Continue"
                    $DebugPreference = 'Continue'
                } else {
                    $informationAction = "SilentlyContinue"
                }
            } else {
                $informationAction = $VerbosePreference
            }

            #Set color
            if (-not $PSBoundParameters.ContainsKey('ForegroundColor')) {
                switch ($LogLevel) {
                    'Debug' {
                        $ForegroundColor = [ConsoleColor]::Gray
                    }
                    'Verbose' {
                        $ForegroundColor = [ConsoleColor]::Yellow
                    }
                    'Error' {
                        $ForegroundColor = [ConsoleColor]::Red
                    }
                    'Warning' {
                        $ForegroundColor = [ConsoleColor]::DarkYellow
                    }
                    'Information' {
                        $ForegroundColor = [ConsoleColor]::White
                    }
                }

                $PSBoundParameters.Add('ForegroundColor', $ForegroundColor)
            }

            if ($null -ne (Get-Variable -Name BciabLogger -ErrorAction Ignore)) {
                $OutputChannel = $Script:BciabLogger.Output
            }

            #Create msg object
            $msg = [System.Management.Automation.InformationRecord]::new($Message, $Command)
            $msg | Add-Member -type NoteProperty -name ForegroundColor -value $PSBoundParameters['ForegroundColor']
            $msg | Add-Member -type NoteProperty -name BackgroundColor -value $PSBoundParameters['BackgroundColor']
            $msg | Add-Member -type NoteProperty -name InformationAction -value $informationAction
            $msg | Add-Member -type NoteProperty -name level -value $PSBoundParameters.LogLevel
            $msg | Add-Member -type NoteProperty -name Verbose -value $PSBoundParameters.Verbose
            $msg | Add-Member -type NoteProperty -name channel -value $OutputChannel

            #Add tags
            if ($Tags) {
                foreach ($tag in $Tags) {
                    $msg.tags.Add($tag)
                }
            }

            #Get formatted message
            $formattedMessage = Get-FormattedMessage -Log $msg
            if ($formattedMessage) {
                if ($OutputChannel -contains [LogOutputType]::file) {
                    Add-Content $BciabLogger.filename $formattedMessage
                }

                #$formattedMessage = ("CONSOLE: {0}" -f $formattedMessage)
            }

            #Add message to newPsBoundParameters
            #Set message options
            $msgObject = [System.Management.Automation.HostInformationMessage]@{
                Message         = $formattedMessage
                ForegroundColor = $ForegroundColor
                BackgroundColor = $BackgroundColor
                NoNewline       = $NoNewline.IsPresent
            }

            #Add message to newPsBoundParameters
            switch ($LogLevel) {
                'Debug' {
                    $newPsboundParams.MessageData = $msgObject
                }
                'Verbose' {
                    $newPsboundParams = @{
                        Message = $msgObject
                        Verbose = $PSBoundParameters.Verbose
                    }
                }
                'Error' {
                    $newPsboundParams.Message = $msgObject
                }
                'Warning' {
                    $newPsboundParams.Message = $msgObject
                }
                'Information' {
                    $newPsboundParams.MessageData = $msgObject
                }
            }

            $outBuffer = $null
            if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
                $PSBoundParameters['OutBuffer'] = 1
            }
            $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand($cmdName, [System.Management.Automation.CommandTypes]::Cmdlet)
            $scriptCmd = { & $wrappedCmd @newPsboundParams }
            $steppablePipeline = $scriptCmd.GetSteppablePipeline($myInvocation.CommandOrigin)
            $steppablePipeline.Begin($PSCmdlet)
        } catch {
            throw
        }
    }
    process {
        try {
            $steppablePipeline.Process($_)
        } catch {
            throw
        }
    }
    end {
        try {
            $steppablePipeline.End()
        } catch {
            throw
        }
    }
}