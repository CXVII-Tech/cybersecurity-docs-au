function Get-FormattedMessage {
    <#
        .DESCRIPTION
            Formats the log message to enable correct display in console and log file
        .PARAMETER Log
            The log record to format
    #>
    [Cmdletbinding()]
    [OutputType([String])]
    param (
        [Parameter()]
        [System.Management.Automation.InformationRecord] $Log
    )

    begin {
        $formattedMessage = $null

        #Check Log Level
        if ($null -eq $Log.Level -or [String]::IsNullOrEmpty($Log.Level)) {
            $Log.Level = 'information'
        } else {
            $Log.Level = $Log.Level.ToString().ToLower();
        }
        $formattedMessage = $null
    }
    process {
        try {
            if ($Log.MessageData -is [System.Management.Automation.ErrorRecord]) {
                try {
                    if ($null -ne $Log.MessageData.PsObject.Properties.Item('InvocationInfo') -and $null -ne $Log.MessageData.InvocationInfo) {
                        if ($null -ne $Log.MessageData.InvocationInfo.PsObject.Properties.Item('PositionMessage')) {
                            $position = $Log.MessageData.InvocationInfo.PositionMessage
                        } else {
                            $position = $null
                        }
                    } else {
                        $position = $null
                    }
                } catch {
                    $position = $null
                }
                $formattedMessage = ("[{0}] - [{1}] - {2}. LineNumber: {3} - exception - {4} - {5}" -f `
                        $Log.TimeGenerated.ToUniversalTime().ToString('HH:mm:ss:fff'), `
                        $Log.Source, `
                        $Log.MessageData.Exception.Message, `
                        $position, `
                        $Log.Computer, `
                        [system.String]::Join(", ", $Log.Tags))

                #[00:00:00:000] - [Type - Line Number: - Function: ] - Message Data. Tags
            } elseif ($Log.MessageData -is [exception]) {
                try {
                    if ($null -ne $Log.MessageData.PsObject.Properties.Item('InvocationInfo')) {
                        $position = $Log.MessageData.InvocationInfo.PositionMessage
                    } else {
                        $position = $null
                    }
                } catch {
                    $position = $null
                }
                $formattedMessage = ("[{0}] - [{1}] - {2}. LineNumber: {3} - exception - {4} - {5}" -f `
                        $Log.TimeGenerated.ToUniversalTime().ToString('HH:mm:ss:fff'), `
                        $Log.Source, `
                        $Log.MessageData, `
                        $position, `
                        $Log.Computer, `
                        [system.String]::Join(", ", $Log.Tags))
            } elseif ($Log.MessageData -is [System.AggregateException]) {
                $formattedMessage = ("[{0}] - [{1}] - {2} - {3} - {4} - {5}" -f `
                        $Log.TimeGenerated.ToUniversalTime().ToString('HH:mm:ss:fff'), `
                        $Log.Source, `
                        $Log.MessageData.Exception.InnerException.Message, `
                        $Log.Level.ToString().ToLower(), `
                        $Log.Computer, `
                        [system.String]::Join(", ", $Log.Tags))
            } elseif ($Log.MessageData -is [String]) {
                $formattedMessage = '[{0}] - [{1}] - {2} - {3} - {4} - {5}' -f `
                    $Log.TimeGenerated.ToUniversalTime().ToString('HH:mm:ss:fff'), `
                    $Log.Source, `
                    $Log.MessageData, `
                    $Log.Level.ToString().ToLower(), `
                    $Log.Computer, `
                    [system.String]::Join(", ", $Log.Tags)
            } else {
                $formattedMessage = '[{0}] - [{1}] - {2} - {3} - {4} - {5}' -f `
                    $Log.TimeGenerated.ToUniversalTime().ToString('HH:mm:ss:fff'), `
                    $Log.Source, `
                ($Log.MessageData | Out-String), `
                    $Log.Level.ToString().ToLower(), `
                    $Log.Computer, `
                    [system.String]::Join(", ", $Log.Tags)

            }
        } catch {
            Write-Verbose ("Unable to format message {0}" -f $Log.MessageData)
        }
    }
    end {
        if ($formattedMessage) {
            return $formattedMessage
        } else {
            return [string]::Empty
        }
    }
}
