function Initialize-M365Object {
    <#
        .DESCRIPTION
            Creates a new object to hold configuration information specific to Microsoft 365 settings
        .PARAMETER Path
            Full path to the settings file
        .PARAMETER FileName
            Name (and extension) of the settings file
        .PARAMETER MyParams
            Passed in PsBoundParameters
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param (
        [Parameter(Mandatory)]
        [String] $Path,

        [Parameter(Mandatory)]
        [String] $FileName
    )
    process {
        Write-Host $Script:LocalData.Verbose_SettingM365Profile `
            -NoNewline

        $configFile = Join-Path -Path $Path -ChildPath $FileName

        if (-not (Test-Path -Path $configFile)) {
            throw ([System.IO.FileNotFoundException]::new(($Script:LocalData.Error_ConfigurationFileNotFound -f $configFile)))
        }

        $config = (Get-Content $configFile -Raw) | ConvertFrom-Json  | ConvertTo-HashTable

        try {
            $tmpM365Object = @{
                WellKnownClientIds = $config.WellKnownClientIds
                ResourceUris       = $config.ResourceUris
            }

            $M365SettingsObject = New-Object -TypeName PSCustomObject -Property $tmpM365Object

            Write-Host $Script:EmojiSuccess

            return $M365SettingsObject
        } catch {
            Write-Host  $Script:EmojiError

            throw $_
        }
    }
}