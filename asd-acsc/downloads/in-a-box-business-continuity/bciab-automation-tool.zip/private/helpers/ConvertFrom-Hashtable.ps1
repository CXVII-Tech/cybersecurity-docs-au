function ConvertFrom-Hashtable {
    <#
    .SYNOPSIS
        Converts a hashtable to a string format for JSON conversion
    .DESCRIPTION
        Converts a System.Collections.Specialized.OrderedDictionary to Selected.System.String
        This allows the information to be formatted correctly when converted to JSON
    .PARAMETER Hashtable
        Hashtable to convert
    .EXAMPLE
        $hashtable | ConvertFrom-Hashtable
        Description
        -----------
        This command passes a hashtable down the pipeline to convert to a string type.
    .EXAMPLE
        ConvertFrom-Hashtable -Hashtable $hashtable
        Description
        -----------
        This command passes the hashtable as a paramter to convert to a string type.
    .NOTES
        Converting a standard hashtable to JSON formatting does not create the array of key/values required.
        This was created as a quick way to convert a hashtable to string for JSON conversion.
    #>
    [CmdletBinding()]
    [OutputType([System.Object[]])]
    Param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelinebyPropertyName)]
        [HashTable] $InputTable
    )
    process {
        $results = @()

        $InputTable | ForEach-Object {
            $result = New-Object PSObject

            foreach ($key in $_.keys) {
                $result | Add-Member -MemberType NoteProperty -Name $key -Value $_[$key]
            }

            $results += $result
        }
        return $results
    }
}