﻿function Invoke-UpdateHashtableValue {
    <#
        .DESCRIPTION
            Updates values in a hashtable
        .PARAMETER Table
            The hashtable object to update
        .PARAMETER OriginalValue
            The original value that will be replaced within the hashtable
        .PARAMETER NewValue
            The value that will replace the original value
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashTable] $Table,

        [Parameter(Mandatory)]
        [string] $OriginalValue,

        [Parameter(Mandatory)]
        [String] $NewValue
    )
    $tempTable = $Table.GetEnumerator() | Where-Object { $_.Value -eq $OriginalValue }

    if ($null -eq $tempTable) {

    } else {
        $tempTable | ForEach-Object { $Table[$_.Key] = $NewValue }
    }

    # $tempTable = $Table.GetEnumerator() | ForEach-Object {
    #     if ($_.Value -eq $OriginalValue) {
    #         $Table[$_.Value] = $NewValue
    #     } elseif ($_.Value -is [HashTable]) {
    #         Invoke-UpdateHashtableValue -Table $_.Value -OriginalValue $OriginalValue -NewValue $NewValue
    #     }
    # }

    $tempTable = $Table.GetEnumerator()
    foreach ($tableObject in $tempTable) {
        if ($tableObject.Value -eq $OriginalValue) {
            $Table[$tableObject.Value] = $NewValue
        } elseif ($tableObject.Value -is [HashTable]) {
            Invoke-UpdateHashtableValue -Table $tableObject.Value -OriginalValue $OriginalValue -NewValue $NewValue
        }
    }
}
