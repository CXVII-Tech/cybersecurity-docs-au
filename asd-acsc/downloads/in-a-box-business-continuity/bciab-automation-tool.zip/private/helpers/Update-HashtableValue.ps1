﻿function Update-HashtableValue {
    [CmdletBinding()]
    #[OutputType([hashtable])]
    param (
        [hashTable] $Table,
        [string] $OriginalValue,
        [String] $NewValue
    )
    $tempTable = $Table.GetEnumerator() | Where-Object { $_.Value -eq $OriginalValue }

    if ($null -eq $tempTable) {

    } else {
        $tempTable | ForEach-Object { $Table[$_.Key] = $NewValue }
    }

    

    $tempTable = $Table.GetEnumerator() | ForEach-Object {
        if ($_.Value -eq $OriginalValue) {
            $Table[$_.Value] = $NewValue
        } elseif ($_.Value -is [HashTable]) {
            Update-HashtableValue -Table $_.Value -OriginalValue $OriginalValue -NewValue $NewValue
        }
    }

    #return $tempTable
}
