function Initialize-GenericJSONObject {
    <#
        .DESCRIPTION
            Creates a new SettingsProfile object to hold configuration information specific to BCIAB
        .PARAMETER Path
            Full path to the settings file
        .PARAMETER FileName
            Name (and extension) of the settings file
        .PARAMETER MyParams
            Passed in PsBoundParameters
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param (
        [Parameter(Mandatory, ParameterSetName = "File")]
        [String] $Path,

        [Parameter(Mandatory, ParameterSetName = "File")]
        [String] $FileName,

        [Parameter(Mandatory, ParameterSetName = "Raw")]
        [String] $RawContent
    )

    process {
        Write-Information $Script:LocalData.Verbose_SettingJSONObject

        switch ($PSCmdlet.ParameterSetName) {
            "File" {
                $configFile = Join-Path -Path $Path -ChildPath $FileName

                if (-not (Test-Path -Path $configFile)) {
                    throw ([System.IO.FileNotFoundException]::new(($Script:LocalData.Error_ConfigurationFileNotFound -f $configFile)))
                }

                $config = (Get-Content $configFile -Raw) | ConvertFrom-Json  | ConvertTo-HashTable
            }
            "Raw" {
                $config = $RawContent | ConvertFrom-Json  | ConvertTo-HashTable
            }
        }

        try {
            $OutputObject = New-Object `
                -TypeName PSCustomObject `
                -Property $config

            Write-Information $Script:LocalData.Verbose_JSONObjectSuccess

            return $OutputObject
        } catch {
            Write-Error ($Script:LocalData.Error_JSONFile -f $_.Exception)
            throw
        }
    }
}