function Get-ConnectionErrorMessage {
    <#
        .DESCRIPTION
            Gets the error message associated with an Azure or Graph connection attempt
        .PARAMETER ExceptionMessage
            The exception message to retrieve the connection error
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [String] $ExceptionMessage
    )
    process {
        if ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionUserCancelledAuthentication) {

            $msg = $Script:LocalData.Exception_ConnectionUserCancelled

        } elseif ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionUserPasswordIncorrect -or
            $ExceptionMessage -like $Script:LocalData.Filter_ConnectionCodeNotAuthenticated) {

            $msg = $Script:LocalData.Exception_ConnectionIncorrectCredentials

        } elseif (($ExceptionMessage -like $Script:LocalData.Filter_ConnectionCodeAzureADSecurityToken) -or
    ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionSequenceContainsNoElements) -or
    ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionAccessTokenExpiry) -or
    ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionMFARequired)) {

            $msg = $Script:LocalData.Exception_ConnectionAccountConfiguredforMFA

        } elseif ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionUnableToAcquireToken) {

            $msg = $Script:LocalData.Exception_ConnectionUnableToAcquireToken

        } elseif ($ExceptionMessage -like $Script:LocalData.Filter_ConnectionMgModuleNotInstalled -or
            $ExceptionMessage -like $Script:LocalData.Filter_ConnectionAzModuleNotInstalled) {

            #If the exception contains the name of the cmdlet, it's likely the required module is not installed
            $msg = $Script:LocalData.Exception_ConnectionModuleNotInstalled
        }

        return $msg
    }
}