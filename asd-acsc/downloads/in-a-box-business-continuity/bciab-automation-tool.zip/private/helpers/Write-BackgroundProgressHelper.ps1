function Write-BackgroundProgressHelper {
    <#
        .DESCRIPTION
            Provides feedback to the user in the form of a progress bar for commands requiring a delay (sleep).
        .PARAMETER ActivityMessage
            The string to display detailing the current activity.
        .PARAMETER TotalSecondsToSleep
            The number of seconds to pause the script to enable background activities to run.
        .EXAMPLE
            Write-BackgroundProgressHelper -ActivityMessage "Creating Azure Application" -TotalSecondsToSleep 20
    #>
    param (
        [Parameter(Mandatory)]
        [String] $ActivityMessage,

        [Parameter(Mandatory)]
        [Int32] $TotalSecondsToSleep
    )

    $counter = 100
    $sleepMilliseconds = ($TotalSecondsToSleep * 1000) / 100

    for ($i = 1; $i -le $counter; $i++ ) {
        Write-Progress -Activity $ActivityMessage -Status ($Script:LocalData.UI_ProgressGenericStatus -f $i) -PercentComplete $i
        Start-Sleep -Milliseconds $sleepMilliseconds
    }
}
