function Initialize-BciabProfile {
    <#
        .DESCRIPTION
            Creates a new SettingsProfile object to hold configuration information specific to BCIAB
        .PARAMETER Path
            Full path to the settings file
        .PARAMETER FileName
            Name (and extension) of the settings file
        .PARAMETER MyParams
            Passed in PsBoundParameters
    #>
    [CmdletBinding()]
    [OutputType([BciabProfile])]
    param(
        [Parameter(Mandatory)]
        [String] $Path,

        [Parameter(Mandatory)]
        [String] $FileName,

        [Parameter()]
        [object] $MyParams
    )
    process {
        Write-Host $Script:LocalData.Verbose_SettingProfileObject `
            -NoNewline

        try {
            $configFile = Join-Path -Path $Path -ChildPath $FileName

            if (-not (Test-Path -Path $configFile)) {
                throw [System.IO.FileNotFoundException]::new(($Script:LocalData.Error_ConfigurationFileNotFound -f $configFile))
            }
            $config = (Get-Content $configFile -Raw) | ConvertFrom-Json | ConvertTo-HashTable

            if (([System.IO.Path]::IsPathRooted($config.OutputPath)) -and (-not (Test-Path($config.OutputPath)))) {
                New-Item -ItemType Directory -Force -Path $config.OutputPath
            } elseif (-not [System.IO.Path]::IsPathRooted($config.OutputPath)) {
                $fullPath = Join-Path -Path $Script:ScriptPath -ChildPath $config.OutputPath

                if (-not (Test-Path $fullPath)) {
                    New-Item -ItemType Directory -Force -Path $fullPath | Out-Null
                }

                $config.OutputPath = $fullPath
            }

            $BciabProfile = [BciabProfile]::New($config)

            if ($MyParams.Verbose) {
                $BciabProfile.VerboseOptions = @{Verbose = $true }
            } else {
                $BciabProfile.VerboseOptions = @{Verbose = $false }
            }

            #Check Debug options
            if ($MyParams.Debug) {
                $BciabProfile.VerboseOptions.Add("Debug", $true)
            } else {
                $BciabProfile.VerboseOptions.Add("Debug", $false)
            }

            #Check no clean up option
            if ($MyParams.NoClean) {
                $BciabProfile.VerboseOptions.Add("NoClean", $true)
            }

            #Setup Logging
            if ($MyParams.Debug) {
                $logFormat = $config.Logging | Where-Object `
                    -FilterScript { $_.name -eq "Debug" }
            } elseif ($MyParams.Verbose) {
                $logFormat = $config.Logging | Where-Object `
                    -FilterScript { $_.name -eq "Verbose" }
            } else {
                $logFormat = $config.Logging | Where-Object `
                    -FilterScript { $_.name -eq "Default" }
            }

            if (-not [String]::IsNullOrEmpty($logFormat)) {
                $runDateTime = $BciabProfile.CreatedTime.ToString("yyyyMMddhhmmss")
                if ($logFormat.output -contains 'file') {
                    if ([String]::IsNullOrEmpty($logFormat.filename)) {
                        $logFileName = "bciab_yyyyMMddhhmmss.log"
                    } else {
                        $logFileName = $logFormat.filename
                    }

                    $logFormat.filename = Join-Path `
                        -Path $config.OutputPath `
                        -ChildPath $logFileName.replace("yyyyMMddhhmmss", $runDateTime)
                }

                if ([String]::IsNullOrEmpty($logFormat.transcriptlog)) {
                    $transcriptLog = "bciab_yyyyMMddhhmmss.transcript.log"
                } else {
                    $transcriptLog = $logFormat.transcriptlog
                }

                $logFormat.transcriptlog = Join-Path `
                    -Path $config.OutputPath `
                    -ChildPath $transcriptLog.replace("yyyyMMddhhmmss", $runDateTime)

                $logger = [BCiabLogger]::New($logFormat)
                New-Variable -Name BciabLogger -Value $logger -Scope Script -Force
            }

            #Allow developer to use a configured username & password when debugging to make debugging easier and reduce issues.
            if ($BciabProfile.VerboseOptions.Debug -and (($null -ne $BciabProfile.UserAuthentication.DebugCredentials.User) -or ($null -ne $BciabProfile.UserAuthentication.DebugCredentials.Password))) {
                $User = $config.UserAuthentication.DebugCredentials.User
                $Password = ConvertTo-SecureString -String $config.UserAuthentication.DebugCredentials.Password -Force
                $BciabProfile.DebugUser = New-Object -TypeName PSCredential -ArgumentList $User, $Password
            }

            Write-Host $Script:EmojiSuccess

            return $BciabProfile
        } catch {
            Write-Host  $Script:EmojiError
            throw $_
        }
    }
}