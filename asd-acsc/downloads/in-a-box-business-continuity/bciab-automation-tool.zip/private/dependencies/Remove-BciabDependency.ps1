function Remove-BciabDependency {
    <#
        .DESCRIPTION
            Removes and unisntalls the passed in dependencies installed by Business Continuity in a Box
        .OUTPUTS
            Returns a list of dependencies that cannot be processed
        .PARAMETER ModuleName
            Name of the module to remove
        .PARAMETER RequiredVersion
            Specific version of the module to remove
        .PARAMETER Force
            Force removal of the specified version of the module regardless of current installation status
        .PARAMETER Scope
            The user scope into which the module will be removed.
            Valid values are CurrentUser or AllUsers.
            AllUsers may require the script to be run as an administrator.
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    [OutputType([Hashtable])]
    param
    (
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [String] $ModuleName,

        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [String] $RequiredVersion,

        [Parameter()]
        [Switch] $Force,

        [Parameter()]
        [ValidateSet("CurrentUser", "AllUsers")]
        [String] $Scope = "CurrentUser"
    )
    begin {
        if (-not $PSBoundParameters.ContainsKey('Confirm')) {
            $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
        }

        if (-not $PSBoundParameters.ContainsKey('WhatIf')) {
            $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
        }

        $notRemoved = @{}
    }
    process {
        $found = Get-Module $ModuleName -ListAvailable | Where-Object -FilterScript { $_.Version -eq $RequiredVersion }

        if (($Force) -or ($found)) {
            if ($PSCmdlet.ShouldProcess(($Script:LocalData.ShouldProcess_InstallModule -f $ModuleName, $RequiredVersion))) {
                try {
                    Remove-Module `
                        -Name $ModuleName `
                        -Force

                    Uninstall-Module `
                        -Name $ModuleName `
                        -RequiredVersion $RequiredVersion `
                        -Force

                    $logMsg = @{
                        MessageData     = ($Script:LocalData.Verbose_RemovedDependency -f $ModuleName, $RequiredVersion)
                        CallStack       = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel        = "Information"
                        Tags            = @($Script:LocalData.Tag_Dependencies, $Script:LocalData.Tag_Success)
                        ForegroundColor = [ConsoleColor]::Green
                    }

                    Write-LogEntry @logMsg
                } catch {
                    $logMsg = @{
                        MessageData = ($Script:LocalData.Error_RemoveDependency -f $ModuleName, $RequiredVersion, $_.Exception)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Warning"
                        Tags        = @($Script:LocalData.Tag_Dependencies, $Script:LocalData.Tag_Error)
                    }

                    Write-LogEntry @logMsg

                    $notRemoved += @{
                        ModuleName      = $ModuleName
                        RequiredVersion = $RequiredVersion
                        Reason          = $_.Exception
                    }
                }
            }
        } else {
            $logMsg = @{
                MessageData = ($Script:LocalData.Warning_DependencyUpdateFailure -f $ModuleName, $RequiredVersion)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Warning"
                Tags        = @($Script:LocalData.Tag_Dependencies, $Script:LocalData.Tag_Warning)
            }

            Write-LogEntry @logMsg

            $notRemoved += @{
                ModuleName      = $ModuleName
                RequiredVersion = $RequiredVersion
            }
        }
    }
    end {
        return $notRemoved
    }
}