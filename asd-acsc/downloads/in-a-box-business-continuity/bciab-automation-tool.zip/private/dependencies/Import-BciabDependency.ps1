﻿function Import-BciabDependency {
    <#
        .DESCRIPTION
            Installs and imports the passed in dependencies
        .OUTPUTS
            Returns a list of dependencies that cannot be processed
        .PARAMETER ModuleName
            Name of the module to be installed
        .PARAMETER RequiredVersion
            Specific version of the module to install
        .PARAMETER Force
            Force installation and import of the specified version of the module regardless of current installation status
        .PARAMETER Scope
            The user scope into which the module will be installed.
            Valid values are CurrentUser or AllUsers.
            AllUsers may require the script to be run as an administrator.
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [String] $ModuleName,

        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [String] $RequiredVersion,

        [Parameter()]
        [Switch] $Force,

        [Parameter()]
        [ValidateSet("CurrentUser", "AllUsers")]
        [String] $Scope = "CurrentUser"
    )
    begin {
        if (-not $PSBoundParameters.ContainsKey('Confirm')) {
            $ConfirmPreference = $PSCmdlet.SessionState.PSVariable.GetValue('ConfirmPreference')
        }

        if (-not $PSBoundParameters.ContainsKey('WhatIf')) {
            $WhatIfPreference = $PSCmdlet.SessionState.PSVariable.GetValue('WhatIfPreference')
        }

        $notImportedCount = 0
    }
    process {
        try {
            if ($PSCmdlet.ShouldProcess(($Script:LocalData.ShouldProcess_InstallModule -f $ModuleName, $RequiredVersion))) {
                $ProgressPreference = 'SilentlyContinue'
                $InformationPreference = 'SilentlyContinue'

                Remove-Module $ModuleName `
                    -Force `
                    -ErrorAction SilentlyContinue

                if ($ModuleName -like 'Microsoft.Graph*') {
                    # Microsoft.Graph.Authentication once installed causes warnings when installing other modules due to locks.
                    # Remove the Module so it does not lock and create warnings.
                    Remove-Module 'Microsoft.Graph.Authentication' `
                        -Force `
                        -ErrorAction SilentlyContinue
                }

                Remove-Module $ModuleName `
                    -Force `
                    -ErrorAction SilentlyContinue

                Import-Module `
                    -Name $ModuleName `
                    -RequiredVersion $RequiredVersion `
                    -Force `
                    -InformationAction SilentlyContinue
            }
        } catch {
            $notImportedCount++
        }
    }
    end {
        return $notImportedCount
    }
}
