function Connect-BciabMgGraph {
    <#
    .DESCRIPTION
        Creates a connection to Azure using the MgGraph module
    .PARAMETER AuthenticationType
        Authentication method to use to ensure management of connections
    .PARAMETER EnvironmentName
        Graph Environment to connect to, supported values: Global, Germany, USGovDoD, USGovGCCHigh, China
    .PARAMETER Credentials
        The credentials object to use for authentication
    .PARAMETER CertificateThumbprint
        Thumbprint of the certificate
    .PARAMETER CertificateName
        Certificate Name to be retrieved from the current user's certificate store
    .PARAMETER Certificate
        An X.509 certificate object
    .PARAMETER CertificatePath
        The path of certficate file in pkcs#12 format
    .PARAMETER CertificatePassword
        The password required to access the pkcs#12 certificate file
    .PARAMETER ApplicationId
        Application Id of the registered Azure application
    .PARAMETER Tenant
        Tenant name or ID of the desired tenant
    .PARAMETER AccessToken
        Access Token for Graph or Azure Resource Manager connection
    .PARAMETER Scopes
        The Graphs scopes to use for authenticating the user
    #>
    [CmdletBinding()]
    [OutputType([Boolean])]
    param (
        [Parameter(Mandatory)]
        [AuthenticationType] $AuthenticationType,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Parameter(ParameterSetName = "ManagedService")]
        [GraphEnvironment] $GraphEnvironmentName,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "UserWithCredentials")]
        [PSCredential] $Credentials,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [String] $CertificateThumbprint,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Alias("CertificateSubject")]
        [String] $CertificateName,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [X509Certificate] $Certificate,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias('CertificateStore')]
        [String] $CertificatePath,

        [Parameter(ParameterSetName = "ServicePrincipalCertificateFile")]
        [SecureString] $CertificatePassword,

        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Alias("AppId", "ClientId")]
        [String] $ApplicationId,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Parameter(ParameterSetName = "ManagedService")]
        [Alias("Domain", "TenantId", "Organization")]
        [ValidateNotNullOrEmpty()]
        [String] $Tenant,

        [Parameter(Mandatory, ParameterSetName = "AccessToken")]
        [SecureString] $AccessToken,

        [Parameter(Mandatory, ParameterSetName = "UserWithCredentials")]
        [String[]] $Scopes
    )
    process {
        try {
            switch ($AuthenticationType) {
                ([AuthenticationType]::UserWithCredentials) {
                    $Tenant = $Credentials.UserName.Split('@')[1]

                    $connectionParams = @{
                        Environment = $GraphEnvironmentName
                        TenantId    = $Tenant
                        Scopes      = $Scopes
                    }
                    break
                }
                ([AuthenticationType]::ServicePrincipalWithSecret) {
                    $connectionParams = @{
                        Credential       = $Credentials
                        Environment      = $GraphEnvironmentName
                        TenantId         = $Tenant
                        ServicePrincipal = $true
                    }
                    break
                }
                ([AuthenticationType]::ServicePrincipalCertificate) {
                    if ($null -eq $CertificateThumbprint) {
                        if (-not [String]::IsNullOrEmpty($CertificateName)) {
                            $certParams = @{
                                CertificatePath = $CertificatePath
                                CertificateName = $CertificateName
                            }
                        } elseif ($null -ne $Certificate) {
                            $certParams = @{Certificate = $Certificate }
                        }

                        $CertificateThumbprint = Get-CertificateThumbprint @certParams
                    }

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams = @{
                            ClientId              = $ApplicationId
                            CertificateThumbprint = $CertificateThumbprint
                            Environment           = $GraphEnvironmentName
                            TenantId              = $Tenant
                        }
                    }

                    break
                }
                ([AuthenticationType]::ServicePrincipalCertificateFile) {
                    $certParams = @{
                        CertificatePath     = $CertificatePath
                        CertificatePassword = $CertificatePassword
                    }

                    $CertificateThumbprint = Get-CertificateThumbprint @certParams

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams = @{
                            ClientId              = $ApplicationId
                            CertificateThumbprint = $CertificateThumbprint
                            Environment           = $GraphEnvironmentName
                            TenantId              = $Tenant
                        }
                    }

                    break
                }
                ([AuthenticationType]::Interactive) {
                    $connectionParams = @{}
                    break
                }
                ([AuthenticationType]::ManagedService) {
                    #Placeholder for Managed Service authentication
                    $connectionParams = @{Identity = $true }
                    break
                }
                ([AuthenticationType]::AccessToken) {
                    $connectionParams = @{
                        AccessToken = $AccessToken
                    }
                    break
                }
            }

            Connect-MgGraph @connectionParams `
                -ErrorAction SilentlyContinue `
                -ErrorVariable ConnectionError | Out-Null

            if ($ConnectionError.count -ge 1) {
                throw $ConnectionError
            }

            return $true
        } catch {
            $logMsg = @{
                MessageData = ($Script:LocalData.Verbose_ConnectionFailedFirstAttempt -f [ConnectionType]::MgGraph)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Warning"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Warning)
            }

            Write-LogEntry @logMsg

            $msg = Get-ConnectionErrorMessage -ExceptionMessage $_.Exception
            $msg += "\n" + $_

            $logMsg = @{
                MessageData = $msg
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg

            throw $_
        }
    }
}