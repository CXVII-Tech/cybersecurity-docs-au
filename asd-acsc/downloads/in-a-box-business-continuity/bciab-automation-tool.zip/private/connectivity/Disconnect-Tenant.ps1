function Disconnect-Tenant {
    <#
        .DESCRIPTION
            Disconnects from the tenant using the appropriate method depending on the connection type
        .PARAMETER ConnectionType
            ConnectionType of the connection to disconnect
    #>
    [CmdletBinding()]
    param (
        [Parameter()]
        [ConnectionType] $ConnectionType
    )
    process {
        try {
            switch ($ConnectionType) {
                ([ConnectionType]::Azure) {
                    Disconnect-AzAccount  `
                        -WarningAction SilentlyContinue | Out-Null
                    Clear-AzContext `
                        -Force `
                        -WarningAction SilentlyContinue | Out-Null
                }
                ([ConnectionType]::ExchangeOnline) {
                    Disconnect-ExchangeOnline -Confirm:$false | Out-Null
                }
                ([ConnectionType]::MgGraph) {
                    Disconnect-MgGraph | Out-Null
                }
            }
        } catch {
            $logMsg = @{
                MessageData = ($Script:LocalData.Error_Disconnection -f $ConnectionType, $_.Exception)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg
        }
    }
}