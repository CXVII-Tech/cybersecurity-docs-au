function Connect-BciabExchangeOnline {
    <#
    .DESCRIPTION
        Creates a connection to Azure using the ExchangeOnline module
    .PARAMETER AuthenticationType
        Authentication method to use to ensure management of connections
    .PARAMETER ExchangeEnvironmentName
        Exchange Environment to connect to, supported values: O365Default, O365GermanyCloud, O365China, O365USGovGCCHigh, O365USGovDod
    .PARAMETER Credentials
        The credentials object to use for authentication
    .PARAMETER CertificateThumbprint
        Thumbprint of the certificate
    .PARAMETER CertificateName
        Certificate Name to be retrieved from the current user's certificate store
    .PARAMETER Certificate
        An X.509 certificate object
    .PARAMETER CertificatePath
        The path of certficate file in pkcs#12 format
    .PARAMETER CertificatePassword
        The password required to access the pkcs#12 certificate file
    .PARAMETER ApplicationId
        Application Id of the registered Azure application
    .PARAMETER Tenant
        Tenant name or ID of the desired tenant
    #>
    [CmdletBinding()]
    [OutputType([Boolean])]
    param (
        [Parameter(Mandatory)]
        [AuthenticationType] $AuthenticationType,

        [Parameter(Mandatory)]
        [ExchangeEnvironment] $ExchangeEnvironmentName,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "UserWithCredentials")]
        [PSCredential] $Credentials,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [String] $CertificateThumbprint,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Alias("CertificateSubject")]
        [String] $CertificateName,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [X509Certificate] $Certificate,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias('CertificateStore')]
        [String] $CertificatePath,

        [Parameter(ParameterSetName = "ServicePrincipalCertificateFile")]
        [SecureString] $CertificatePassword,

        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias("AppId", "ClientId")]
        [String] $ApplicationId,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "AccessToken")]
        [Parameter(ParameterSetName = "ManagedService")]
        [Alias("Domain", "TenantId", "Organization")]
        [ValidateNotNullOrEmpty()]
        [String] $Tenant
    )
    process {
        #Make sure to disconnect from any existing connections that were found as they cannot be used if not captured above
        Disconnect-ExchangeOnline -Confirm:$false

        try {
            $connectionParams = @{
                ExchangeEnvironmentName = $ExchangeEnvironmentName
                ShowProgress            = $false
                ShowBanner              = $false
                Verbose                 = $false
            }

            switch ($AuthenticationType) {
                ([AuthenticationType]::UserWithCredentials) {
                    $connectionParams.Add("Credential", $Credentials)
                    break
                }
                ([AuthenticationType]::ServicePrincipalWithSecret) {
                    $connectionParams.Add("Credential", $Credentials)
                    $connectionParams.Add("Tenant", $Tenant)
                    $connectionParams.Add("ServicePrincipal", $true)

                    break
                }
                ([AuthenticationType]::ServicePrincipalCertificate) {
                    if ($null -eq $CertificateThumbprint) {
                        if (-not [String]::IsNullOrEmpty($CertificateName)) {
                            $certParams = @{
                                CertificatePath = $CertificatePath
                                CertificateName = $CertificateName
                            }
                        } elseif ($null -ne $Certificate) {
                            $certParams = @{Certificate = $Certificate }
                        }

                        $CertificateThumbprint = Get-CertificateThumbprint @certParams
                    }

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams.Add("AppId", $ApplicationId)
                        $connectionParams.Add("Organization", $Tenant)
                        $connectionParams.Add("CertificateThumbprint", $CertificateThumbprint)
                    }

                    break
                }
                ([AuthenticationType]::ServicePrincipalCertificateFile) {
                    $certParams = @{
                        CertificatePath     = $CertificatePath
                        CertificatePassword = $CertificatePassword
                    }

                    $CertificateThumbprint = Get-CertificateThumbprint @certParams

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams.Add("AppId", $ApplicationId)
                        $connectionParams.Add("Organization", $Tenant)
                        $connectionParams.Add("CertificateThumbprint", $CertificateThumbprint)
                    }

                    break
                }
                ([AuthenticationType]::Interactive) {
                    $connectionParams = @{
                        InlineCredential = $true
                    }
                    break
                }
                ([AuthenticationType]::ManagedService) {
                    $connectionParams = @{
                        ManagedIdentity = $true
                        Organization    = $Tenant
                    }

                    break
                }
            }

            Connect-ExchangeOnline @connectionParams `
                -ErrorAction SilentlyContinue `
                -ErrorVariable ConnectionError

            if ($ConnectionError.count -ge 1) {
                if (($ConnectionError -like $Script:LocalData.Filter_ConnectionMFARequired) -and ($null -ne $Credentials)) {
                    $logMsg = @{
                        MessageData = ($Script:LocalData.Verbose_ConnectionCredentialMFA -f $Credentials.UserName)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    $connectionParams = @{
                        UserPrincipalName = $Credentials.UserName
                        ShowProgress      = $false
                        ShowBanner        = $false
                        Verbose           = $false
                    }
                    Connect-ExchangeOnline @connectionParams
                } else {
                    $logMsg = @{
                        MessageData = $Script:LocalData.Exception_ConnectionEXOError
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Error"
                        Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
                    }

                    Write-LogEntry @logMsg

                    throw $ConnectionError
                }
            }

            [array] $result = $result = Get-AcceptedDomain

            if ($result.Length -ge 1) {
                return $true
            }
            return $false

        } catch {
            $logMsg = @{
                MessageData = $_
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg

            throw
        }
    }
}
