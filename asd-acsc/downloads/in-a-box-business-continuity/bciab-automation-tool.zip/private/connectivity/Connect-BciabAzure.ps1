function Connect-BciabAzure {
    <#
        .DESCRIPTION
            Creates a connection to Azure using the Az.Account module
        .PARAMETER AuthenticationType
            Authentication method to use to ensure management of connections
        .PARAMETER EnvironmentName
            Azure Environment to connect to, supported values: AzureCloud, AzureGermanyCloud, AzureDOD, AzureUSGovernment, AzureChinaCloud
        .PARAMETER Credentials
            The credentials object to use for authentication
        .PARAMETER CertificateThumbprint
            Thumbprint of the certificate
        .PARAMETER CertificateName
            Certificate Name to be retrieved from the current user's certificate store
        .PARAMETER Certificate
            An X.509 certificate object
        .PARAMETER CertificatePath
            The path of certficate file in pkcs#12 format
        .PARAMETER CertificatePassword
            The password required to access the pkcs#12 certificate file
        .PARAMETER ApplicationId
            Application Id of the registered Azure application
        .PARAMETER Tenant
            Tenant name or ID of the desired tenant
        .PARAMETER AccessToken
            Access Token for Graph or Azure Resource Manager connection
        .PARAMETER RequiredRoles
            The Roles to ensure the user is in
    #>
    [CmdletBinding()]
    [OutputType([Boolean])]
    param (
        [Parameter(Mandatory)]
        [AuthenticationType] $AuthenticationType,

        [Parameter(Mandatory)]
        [AzureEnvironment] $EnvironmentName,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "UserWithCredentials")]
        [PSCredential] $Credentials,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [String] $CertificateThumbprint,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Alias("CertificateSubject")]
        [String] $CertificateName,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [X509Certificate] $Certificate,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias('CertificateStore')]
        [String] $CertificatePath,

        [Parameter(ParameterSetName = "ServicePrincipalCertificateFile")]
        [SecureString] $CertificatePassword,

        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias("AppId", "ClientId")]
        [String] $ApplicationId,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Parameter(ParameterSetName = "AccessToken")]
        [Parameter(ParameterSetName = "ManagedService")]
        [Alias("Domain", "TenantId", "Organization")]
        [ValidateNotNullOrEmpty()]
        [String] $Tenant,

        [Parameter(Mandatory, ParameterSetName = "AccessToken")]
        [ValidateNotNullOrEmpty()]
        [String] $AccessToken,

        [Parameter(ParameterSetName = "UserWithCredentials", HelpMessage = "The role(s) to that must be assigned to the user otherwise fail the connection.")]
        [Parameter(ParameterSetName = "AccessToken", HelpMessage = "The role(s) to that must be assigned to the user otherwise fail the connection.")]
        [String[]] $RequiredRoles
    )
    process {
        #Remove existing contexts
        Get-AzContext | Remove-AzContext -Force -WarningAction SilentlyContinue | Out-Null

        try {
            switch ($AuthenticationType) {
                ([AuthenticationType]::UserWithCredentials) {
                    $connectionParams = @{
                        Credential  = $Credentials
                        Environment = $EnvironmentName
                    }
                    break
                }
                ([AuthenticationType]::ServicePrincipalWithSecret) {
                    $connectionParams = @{
                        Credential       = $Credentials
                        Environment      = $EnvironmentName
                        TenantId         = $Tenant
                        ServicePrincipal = $true
                    }
                    break
                }
                ([AuthenticationType]::ServicePrincipalCertificate) {
                    if ($null -eq $CertificateThumbprint) {
                        if ($null -ne $CertificateName) {
                            $certParams = @{
                                CertificatePath = $CertificatePath
                                CertificateName = $CertificateName
                            }
                        } elseif ($null -ne $Certificate) {
                            $certParams = @{Certificate = $Certificate }
                        }

                        $CertificateThumbprint = Get-CertificateThumbprint @certParams
                    }

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams = @{
                            ApplicationId         = $ApplicationId
                            CertificateThumbprint = $CertificateThumbprint
                            Environment           = $EnvironmentName
                            TenantId              = $Tenant
                            ServicePrincipal      = $true
                        }
                    }
                    break
                }
                ([AuthenticationType]::ServicePrincipalCertificateFile) {
                    $certParams = @{
                        CertificatePath     = $CertificatePath
                        CertificatePassword = $CertificatePassword
                    }

                    $CertificateThumbprint = Get-CertificateThumbprint @certParams

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams = @{
                            ApplicationId         = $ApplicationId
                            CertificateThumbprint = $CertificateThumbprint
                            Environment           = $EnvironmentName
                            TenantId              = $Tenant
                            ServicePrincipal      = $true
                        }
                    }
                    break
                }
                ([AuthenticationType]::Interactive) {
                    $connectionParams = @{}
                    break
                }
                ([AuthenticationType]::ManagedService) {
                    $connectionParams = @{Identity = $true }
                    break
                }
                ([AuthenticationType]::AccessToken) {
                    $connectionParams = @{AccessToken = $AccessToken }
                    break
                }
            }

            # Fix error associated with LoginExperienceV2 always requiring tenant id
            Set-AzConfig -EnableLoginByWam $false -LoginExperienceV2 'Off' | Out-Null

            Connect-AzAccount @connectionParams `
                -ErrorAction SilentlyContinue `
                -ErrorVariable ConnectionError

            if ($ConnectionError.count -ge 1) {
                throw $ConnectionError
            }

            return $true
        } catch {
            $logMsg = @{
                MessageData = ($Script:LocalData.Verbose_ConnectionFailedFirstAttempt -f [ConnectionType]::Azure)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Warning"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Warning)
            }

            Write-LogEntry @logMsg

            $msg = Get-ConnectionErrorMessage -ExceptionMessage $_.Exception

            $msg += "\n" + $_

            $logMsg = @{
                MessageData = $msg
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg

            throw $_
        }
    }
}
