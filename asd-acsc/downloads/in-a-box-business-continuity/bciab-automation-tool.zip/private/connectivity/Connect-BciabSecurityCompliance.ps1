function Connect-BciabSecurityCompliance {
    <#
    .DESCRIPTION
        Creates a connection to Security & Compliance
    .PARAMETER AuthenticationType
        Authentication method to use to ensure management of connections
    .PARAMETER EnvironmentName
        Environment to connect to, supported values: O365Default, O365GermanyCloud, O365China, O365USGovGCCHigh, O365USGovDod
    .PARAMETER Credentials
        The credentials object to use for authentication
    .PARAMETER CertificateThumbprint
        Thumbprint of the certificate
    .PARAMETER CertificateName
        Certificate Name to be retrieved from the current user's certificate store
    .PARAMETER Certificate
        An X.509 certificate object
    .PARAMETER CertificatePath
        The path of certficate file in pkcs#12 format
    .PARAMETER CertificatePassword
        The password required to access the pkcs#12 certificate file
    .PARAMETER ApplicationId
        Application Id of the registered Azure application
    .PARAMETER Tenant
        Tenant name or ID of the desired tenant
    .PARAMETER AccessToken
        Access Token for Graph or Azure Resource Manager connection
    #>
    [CmdletBinding()]
    [OutputType([Boolean])]
    param (
        [Parameter(Mandatory)]
        [AuthenticationType] $AuthenticationType,

        [Parameter(Mandatory)]
        [ExchangeEnvironmentName] $EnvironmentName,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "UserWithCredentials")]
        [PSCredential] $Credentials,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [String] $CertificateThumbprint,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Alias("CertificateSubject")]
        [String] $CertificateName,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [X509Certificate] $Certificate,

        [Parameter(ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Alias('CertificateStore')]
        [String] $CertificatePath,

        [Parameter(ParameterSetName = "ServicePrincipalCertificateFile")]
        [SecureString] $CertificatePassword,

        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Alias("AppId", "ClientId")]
        [String] $ApplicationId,

        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalWithSecret")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificate")]
        [Parameter(Mandatory, ParameterSetName = "ServicePrincipalCertificateFile")]
        [Parameter(Mandatory, ParameterSetName = "ClientAssertion")]
        [Parameter(ParameterSetName = "UserWithCredentials")]
        [Parameter(ParameterSetName = "AccessToken")]
        [Parameter(ParameterSetName = "ManagedService")]
        [Alias("Domain", "TenantId", "Organization")]
        [ValidateNotNullOrEmpty()]
        [String] $Tenant
    )
    process {
        try {
            $connectionParams = @{
                ExchangeEnvironmentName = $EnvironmentName
                UseRPSSession           = $false
                ShowProgress            = $false
                ShowBanner              = $false
                Verbose                 = $false
            }

            switch ($AuthenticationType) {
                ([AuthenticationType]::UserWithCredentials) {
                    $logMsg = @{
                        MessageData = ($Script:LocalData.Verbose_ConnectionCredential -f $Credentials.UserName)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    $connectionParams.Add(@{Credential = $Credentials })
                    break
                }
                ([AuthenticationType]::ServicePrincipalWithSecret) {
                    $logMsg = @{
                        MessageData = ($Script:LocalData.Verbose_ConnectionServicePrincipalSecret -f $Credentials.UserName)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    $connectionParams.Add(
                        @{
                            Credential       = $Credentials
                            Tenant           = $Tenant
                            ServicePrincipal = $true
                        }
                    )
                    break
                }
            (([AuthenticationType]::ServicePrincipalCertificate) -or
            ([AuthenticationType]::ServicePrincipalCertificateFile)) {
                    $logMsg = @{
                        MessageData = ($Script:LocalData.Verbose_ConnectionServicePrincipalThumbprint -f $ApplicationId)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    if ($AuthenticationType -eq [AuthenticationType]::ServicePrincipalCertificateFile) {
                        $certParams = @{
                            CertificatePath     = $CertificatePath
                            CertificatePassword = $CertificatePassword
                        }
                    } elseif ($null -ne $CertificateName) {
                        $certParams = @{
                            CertificatePath = $CertificatePath
                            CertificateName = $CertificateName
                        }
                    } elseif ($null -ne $Certificate) {
                        $certParams = @{Certificate = $Certificate }
                    }

                    $CertificateThumbprint = Get-CertificateThumbprint @certParams

                    if ($null -ne $CertificateThumbprint) {
                        $connectionParams.Add(
                            @{
                                AppId                 = $ApplicationId
                                Organization          = $Tenant
                                CertificateThumbprint = $CertificateThumbprint
                            }
                        )
                    }
                    break
                }
                ([AuthenticationType]::Interactive) {
                    $logMsg = @{
                        MessageData = $Script:LocalData.Verbose_ConnectionInteractive
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    $connectionParams = @{
                        InlineCredential = $true
                    }
                    break
                }
                ([AuthenticationType]::ManagedService) {
                    $logMsg = @{
                        MessageData = $Script:LocalData.Verbose_ConnectionManagedIdentity
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    $connectionParams = @{
                        ManagedIdentity = $true
                        Organization    = $Tenant
                    }

                    break
                }
            }

            Connect-IPPSSession @connectionParams `
                -ErrorAction SilentlyContinue `
                -ErrorVariable ConnectionError

            if ($ConnectionError.count -ge 1) {
                if (($ConnectionError -like $Script:LocalData.Filter_ConnectionMFARequired) -and ($null -ne $Credentials)) {

                    $logMsg = @{
                        MessageData = ($Script:LocalData.Verbose_ConnectionCredentialMFA -f $Credentials.UserName)
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Verbose"
                        Tags        = @($Script:LocalData.Tag_Connection)
                    }

                    Write-LogEntry @logMsg

                    $connectionParams = @{
                        UserPrincipalName = $Credentials.UserName
                        UseRPSSession     = $false
                        ShowProgress      = $false
                        ShowBanner        = $false
                        Verbose           = $false
                    }
                    Connect-IPPSSession @connectionParams
                } else {
                    $logMsg = @{
                        MessageData = $Script:LocalData.Exception_ConnectionEXOError
                        CallStack   = (Get-PSCallStack | Select-Object -First 1)
                        LogLevel    = "Error"
                        Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
                    }

                    Write-LogEntry @logMsg

                    throw $ConnectionError
                }
            }
            $logMsg = @{
                MessageData     = ($Script:LocalData.Verbose_ConnectionSuccess -f [ConnectionType]::SecurityCompliance)
                CallStack       = (Get-PSCallStack | Select-Object -First 1)
                LogLevel        = "Verbose"
                Tags            = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Success)
                ForegroundColor = [ConsoleColor]::Green
            }

            Write-LogEntry @logMsg
            return $true

        } catch {
            $logMsg = @{
                MessageData = $_
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Connection, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg

            throw
        }
    }
}
