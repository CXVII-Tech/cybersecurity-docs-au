using namespace System.Security.Cryptography.X509Certificates
function Get-CertificateThumbprint {
    <#
        .SYNOPSIS
        Gets an `X509CertificateStore` object for the given location and store name.

        .DESCRIPTION
        Returns an `X509Store` for a given store location and store name. The store must exist. Before being retured, it is opened for writing. If you don't have permission to write to the store, you'll get an error.

        If you just want to read a store, we recommend using PowerShell's `cert:` drive.

        .OUTPUTS
        Security.Cryptography.X509Certificates.X509Store.

        .EXAMPLE
        Get-CCertificateStore -StoreLocation LocalMachine -StoreName My

        Get the local computer's Personal certificate store.

        .EXAMPLE
        Get-CCertificateStore -StoreLocation CurrentUser -StoreName Root

        Get the current user's Trusted Root Certification Authorities certificate store.
    #>
    [CmdletBinding()]
    [OutputType([String])]
    param (
        [Parameter(Mandatory, ParameterSetName = "CertificateStore", HelpMessage = "Certificate Name to be retrieved from the current user's certificate store.")]
        [ValidateNotNullOrEmpty()]
        [Alias("CertificateSubject")]
        [String] $CertificateName,

        [Parameter(Mandatory, ParameterSetName = "Certificate", HelpMessage = "An X.509 certificate object.")]
        [X509Certificate] $Certificate,

        [Parameter(ParameterSetName = "CertificateStore", HelpMessage = "The certificate store.")]
        [Parameter(Mandatory, ParameterSetName = "CertificateFile", HelpMessage = "The path of certficate file in pkcs#12 format or certificate store.")]
        [ValidateNotNullOrEmpty()]
        [Alias('CertificateStore')]
        [String] $CertificatePath,

        [Parameter(ParameterSetName = "CertificateFile", HelpMessage = "The password required to access the certificate file.")]
        [SecureString] $CertificatePassword
    )
    process {
        try {
            switch ($PSCmdlet.ParameterSetName) {
                "CertificateFile" {
                    if ([String]::IsNullOrEmpty($CertificatePassword)) {
                        $Certificate = New-Object X509Certificate2($CertificatePath)
                    } else {
                        $Certificate = New-Object X509Certificate2($CertificatePath, $CertificatePassword)
                    }

                    break
                }
                "CertificateStore" {
                    <#
                        For future development, would be worthwhile adding in a second check to determine if the script is running as admin.
                        If it is running as admin use 'Cert:\LocalMachine\My' instead. This may be necessary when specifing '#Requires -RunAsAdministrator'
                        for additional purposes. At this stage of development, the script was to be as simple as possible to run.
                    #>
                    if ([String]::IsNullOrEmpty($CertificatePath)) {
                        $CertificatePath = "Cert:\CurrentUser\My"
                    }

                    if ([String]::IsNullOrEmpty($CertificateName)) {
                        $Certificate = Get-ChildItem -Path $CertificatePath | Where-Object { $_.Subject -match $CertificateName }
                    }
                    break
                }
            }
            return $Certificate.Thumbprint
        } catch {
            $logMsg = @{
                MessageData = ($Script:LocalData.Error_CertificateThumbprint -f $_.Exception)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Certificate)
            }

            Write-LogEntry @logMsg

            throw $_
        }
    }
}