function Get-NewPassword {
    <#
    .DESCRIPTION
        Generates a random password.
    .PARAMETER Length
        The total length of the password to generate
    .EXAMPLE
        Get-NewPassword
    .EXAMPLE
        Get-NewPassword -Length 40

        Generates a password of 40 characters in length
    #>
    [CmdletBinding()]
    [OutputType([String[]])]
    param (
        [Parameter()]
        [ValidateRange(1, 256)]
        [int] $Length = 30
    )
    process {
        try {
            $charSet = '!"$%/()=?}][{@#*+abcdefghjkmnpqrtuvwxyzABCDEFGHJKMNPQRTUVWXYZ23456789'.ToCharArray()
            $scrambledStrArray = $charSet | Get-Random -Count $charSet.Length
            $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
            $bytes = New-Object byte[]($length)

            $rng.GetBytes($bytes)

            $result = New-Object char[]($Length)

            for ($i = 0 ; $i -lt $Length ; $i++) {
                $result[$i] = $scrambledStrArray[$bytes[$i] % $scrambledStrArray.Length]
            }

            $password = $result | Get-Random -Count $result.Length

            return (-join $password)
        } catch {
            $logMsg = @{
                MessageData = ($Script:LocalData.Error_CreatePassword -f $_.Exception)
                CallStack   = (Get-PSCallStack | Select-Object -First 1)
                LogLevel    = "Error"
                Tags        = @($Script:LocalData.Tag_Password, $Script:LocalData.Tag_Error)
            }

            Write-LogEntry @logMsg

            throw $_
        }
    }
}